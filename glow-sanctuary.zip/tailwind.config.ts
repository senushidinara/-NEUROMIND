import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: ["./client/**/*.{ts,tsx}"],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        // Enhanced AI platform colors
        ai: {
          purple: "hsl(var(--ai-purple))",
          pink: "hsl(var(--ai-pink))",
          blue: "hsl(var(--ai-blue))",
          cyan: "hsl(var(--ai-cyan))",
          emerald: "hsl(var(--ai-emerald))",
          amber: "hsl(var(--ai-amber))",
          rose: "hsl(var(--ai-rose))",
          indigo: "hsl(var(--ai-indigo))",
        },
        // Glassmorphism utilities
        glass: {
          white: "rgba(var(--glass-white), 0.1)",
          black: "rgba(var(--glass-black), 0.1)",
        },
        // Interactive glow colors
        glow: {
          purple: "hsl(var(--glow-purple))",
          blue: "hsl(var(--glow-blue))",
          pink: "hsl(var(--glow-pink))",
          cyan: "hsl(var(--glow-cyan))",
        },
        // Neural network visualization
        neural: {
          node: "hsl(var(--neural-node))",
          connection: "hsl(var(--neural-connection))",
          active: "hsl(var(--neural-active))",
        },
        sidebar: {
          DEFAULT: "hsl(var(--sidebar-background))",
          foreground: "hsl(var(--sidebar-foreground))",
          primary: "hsl(var(--sidebar-primary))",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground))",
          accent: "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
          border: "hsl(var(--sidebar-border))",
          ring: "hsl(var(--sidebar-ring))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
        xl: "calc(var(--radius) + 4px)",
        "2xl": "calc(var(--radius) + 8px)",
      },
      backdropBlur: {
        xs: "2px",
        '4xl': '72px',
        '5xl': '96px',
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "float-gentle": "float-gentle 6s ease-in-out infinite",
        "pulse-glow": "pulse-glow 3s ease-in-out infinite",
        "neural-pulse": "neural-pulse 2s ease-in-out infinite",
        "data-flow": "data-flow 4s ease-in-out infinite",
        "hologram-flicker": "hologram-flicker 0.1s ease-in-out infinite",
        "ai-thinking": "ai-thinking 1.5s ease-in-out infinite",
        "brain-activation": "brain-activation 2s ease-in-out infinite",
        "eeg-wave-complex": "eeg-wave-complex 2.5s ease-in-out infinite",
        "shimmer": "shimmer 2s infinite",
        "gradient-shift": "gradient-shift 8s ease-in-out infinite",
        "particle-float": "particle-float 10s linear infinite",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "float-gentle": {
          "0%, 100%": { transform: "translateY(0px) scale(1)" },
          "50%": { transform: "translateY(-10px) scale(1.02)" },
        },
        "pulse-glow": {
          "0%, 100%": { boxShadow: "0 0 20px rgba(147, 51, 234, 0.3)" },
          "50%": { boxShadow: "0 0 40px rgba(147, 51, 234, 0.6)" },
        },
        "neural-pulse": {
          "0%, 100%": { opacity: "0.6", transform: "scale(1)" },
          "50%": { opacity: "1", transform: "scale(1.1)" },
        },
        "data-flow": {
          "0%": { transform: "translateX(-100%) scale(0.8)", opacity: "0" },
          "50%": { opacity: "1", transform: "scale(1)" },
          "100%": { transform: "translateX(100%) scale(0.8)", opacity: "0" },
        },
        "hologram-flicker": {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.8" },
          "75%": { opacity: "0.9" },
        },
        "ai-thinking": {
          "0%, 100%": { transform: "scale(1)" },
          "25%": { transform: "scale(1.1)" },
          "50%": { transform: "scale(1.05)" },
          "75%": { transform: "scale(1.15)" },
        },
        "brain-activation": {
          "0%, 100%": {
            opacity: "0.7",
            transform: "scale(1)",
            filter: "drop-shadow(0 0 5px rgba(59, 130, 246, 0.5))",
          },
          "50%": {
            opacity: "1",
            transform: "scale(1.1)",
            filter: "drop-shadow(0 0 15px rgba(59, 130, 246, 0.8))",
          },
        },
        "eeg-wave-complex": {
          "0%": { transform: "translateY(0px) scaleY(1)" },
          "25%": { transform: "translateY(-3px) scaleY(1.2)" },
          "50%": { transform: "translateY(2px) scaleY(0.8)" },
          "75%": { transform: "translateY(-1px) scaleY(1.1)" },
          "100%": { transform: "translateY(0px) scaleY(1)" },
        },
        "shimmer": {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        "gradient-shift": {
          "0%, 100%": {
            background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
          },
          "25%": {
            background: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
          },
          "50%": {
            background: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
          },
          "75%": {
            background: "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)",
          },
        },
        "particle-float": {
          "0%": { transform: "translateY(0px) translateX(0px) rotate(0deg)" },
          "33%": { transform: "translateY(-20px) translateX(10px) rotate(120deg)" },
          "66%": { transform: "translateY(-10px) translateX(-10px) rotate(240deg)" },
          "100%": { transform: "translateY(0px) translateX(0px) rotate(360deg)" },
        },
      },
      boxShadow: {
        'glass': '0 8px 32px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
        'glass-lg': '0 25px 50px rgba(0, 0, 0, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
        'glow-purple': '0 0 20px rgba(147, 51, 234, 0.3), 0 8px 32px rgba(0, 0, 0, 0.1)',
        'glow-blue': '0 0 20px rgba(59, 130, 246, 0.3), 0 8px 32px rgba(0, 0, 0, 0.1)',
        'glow-pink': '0 0 20px rgba(236, 72, 153, 0.3), 0 8px 32px rgba(0, 0, 0, 0.1)',
        'glow-cyan': '0 0 20px rgba(6, 182, 212, 0.3), 0 8px 32px rgba(0, 0, 0, 0.1)',
        'neural': '0 0 30px rgba(168, 85, 247, 0.4), 0 8px 32px rgba(0, 0, 0, 0.2)',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
        'glass-gradient': 'linear-gradient(135deg, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0.05) 100%)',
        'neural-pattern': 'radial-gradient(circle at 25% 25%, rgba(147, 51, 234, 0.1) 0%, transparent 50%), radial-gradient(circle at 75% 75%, rgba(59, 130, 246, 0.1) 0%, transparent 50%)',
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "Monaco", "Cascadia Code", "Segoe UI Mono", "Roboto Mono", "Oxygen Mono", "Ubuntu Monospace", "Source Code Pro", "Fira Mono", "Droid Sans Mono", "Courier New", "monospace"],
      },
      fontSize: {
        '2xs': ['0.625rem', { lineHeight: '0.875rem' }],
        '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
        '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
        '5xl': ['3rem', { lineHeight: '1' }],
        '6xl': ['3.75rem', { lineHeight: '1' }],
        '7xl': ['4.5rem', { lineHeight: '1' }],
        '8xl': ['6rem', { lineHeight: '1' }],
        '9xl': ['8rem', { lineHeight: '1' }],
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
        '128': '32rem',
        '144': '36rem',
      },
      transitionDuration: {
        '2000': '2000ms',
        '3000': '3000ms',
      },
    },
  },
  plugins: [
    require("tailwindcss-animate"),
    // Enhanced AI platform utilities
    function({ addUtilities, addComponents, theme }: any) {
      const newUtilities = {
        // Glassmorphism utilities
        '.glass-card': {
          background: 'rgba(255, 255, 255, 0.1)',
          backdropFilter: 'blur(20px)',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
        },
        '.glass-button': {
          background: 'rgba(255, 255, 255, 0.1)',
          backdropFilter: 'blur(15px)',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          '&:hover': {
            background: 'rgba(255, 255, 255, 0.15)',
            borderColor: 'rgba(255, 255, 255, 0.3)',
            boxShadow: '0 8px 25px rgba(0, 0, 0, 0.15), 0 0 20px rgba(147, 51, 234, 0.2)',
          },
        },
        '.glass-input': {
          background: 'rgba(255, 255, 255, 0.08)',
          backdropFilter: 'blur(12px)',
          border: '1px solid rgba(255, 255, 255, 0.15)',
          '&:focus': {
            background: 'rgba(255, 255, 255, 0.12)',
            borderColor: 'rgba(147, 51, 234, 0.5)',
            boxShadow: '0 0 0 2px rgba(147, 51, 234, 0.2)',
          },
        },
        // Interactive button effects
        '.interactive-button': {
          position: 'relative',
          overflow: 'hidden',
          background: 'linear-gradient(135deg, rgba(147, 51, 234, 0.1), rgba(236, 72, 153, 0.1))',
          backdropFilter: 'blur(20px)',
          border: '1px solid rgba(255, 255, 255, 0.2)',
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: '0',
            left: '-100%',
            width: '100%',
            height: '100%',
            background: 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent)',
            transition: 'left 0.5s',
          },
          '&:hover::before': {
            left: '100%',
          },
          '&:hover': {
            background: 'linear-gradient(135deg, rgba(147, 51, 234, 0.2), rgba(236, 72, 153, 0.2))',
            borderColor: 'rgba(255, 255, 255, 0.4)',
            boxShadow: '0 8px 25px rgba(0, 0, 0, 0.15), 0 0 30px rgba(147, 51, 234, 0.3)',
            transform: 'translateY(-2px)',
          },
        },
        // Neural network effects
        '.neural-connection': {
          background: 'linear-gradient(90deg, transparent, rgba(59, 130, 246, 0.6), transparent)',
          height: '2px',
          animation: 'data-flow 4s ease-in-out infinite',
        },
        '.neural-node': {
          background: 'radial-gradient(circle, rgba(168, 85, 247, 0.8), rgba(168, 85, 247, 0.3))',
          boxShadow: '0 0 20px rgba(168, 85, 247, 0.6)',
          animation: 'neural-pulse 2s ease-in-out infinite',
        },
        // Text effects
        '.text-depth': {
          textShadow: '0 1px 2px rgba(0, 0, 0, 0.1), 0 2px 4px rgba(0, 0, 0, 0.1), 0 4px 8px rgba(0, 0, 0, 0.1)',
        },
        '.text-glow': {
          textShadow: '0 0 10px rgba(147, 51, 234, 0.5), 0 0 20px rgba(147, 51, 234, 0.3), 0 0 30px rgba(147, 51, 234, 0.1)',
        },
        // Performance optimizations
        '.gpu-accelerated': {
          transform: 'translateZ(0)',
          willChange: 'transform',
        },
        // Loading states
        '.loading-shimmer': {
          background: 'linear-gradient(90deg, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.1) 100%)',
          backgroundSize: '200% 100%',
          animation: 'shimmer 2s infinite',
        },
        // Cinematic effects
        '.cinematic-video': {
          position: 'relative',
          borderRadius: '1rem',
          overflow: 'hidden',
          boxShadow: '0 25px 50px rgba(0, 0, 0, 0.25), 0 0 50px rgba(147, 51, 234, 0.1)',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: '0',
            left: '0',
            right: '0',
            bottom: '0',
            background: 'linear-gradient(45deg, rgba(255, 255, 255, 0.1) 0%, transparent 50%, rgba(255, 255, 255, 0.05) 100%)',
            pointerEvents: 'none',
            zIndex: '1',
          },
        },
        // AI assistant styles
        '.ai-assistant-container': {
          background: 'rgba(15, 15, 25, 0.8)',
          backdropFilter: 'blur(25px)',
          border: '1px solid rgba(255, 255, 255, 0.1)',
          boxShadow: '0 25px 50px rgba(0, 0, 0, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
        },
        // Responsive typography
        '.responsive-text': {
          fontSize: 'clamp(1rem, 2.5vw, 1.5rem)',
          lineHeight: '1.6',
        },
      }

      const newComponents = {
        '.btn-glass': {
          '@apply glass-button px-6 py-3 rounded-xl text-white font-medium transition-all duration-300 hover:shadow-xl hover:border-white/30': {},
        },
        '.card-glass': {
          '@apply glass-card p-6 rounded-2xl shadow-xl': {},
        },
        '.input-glass': {
          '@apply glass-input px-4 py-3 rounded-xl text-white placeholder:text-white/60 focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-white/30': {},
        },
      }

      addUtilities(newUtilities)
      addComponents(newComponents)
    }
  ],
} satisfies Config;
