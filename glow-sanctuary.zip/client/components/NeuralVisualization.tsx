import { useRef, useEffect, useState, useMemo } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import {
  OrbitControls,
  Sphere,
  Line,
  Text,
  Float,
  Environment,
  MeshDistortMaterial,
} from "@react-three/drei";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import * as THREE from "three";
import {
  Brain,
  Activity,
  Zap,
  Eye,
  Volume2,
  Palette,
  Settings,
  Play,
  Pause,
  RotateCw,
  Layers,
  Sparkles,
} from "lucide-react";

interface Neuron {
  id: string;
  position: THREE.Vector3;
  activity: number;
  neurotransmitter: string;
  connections: string[];
  region: string;
  firing: boolean;
}

interface Synapse {
  from: string;
  to: string;
  strength: number;
  activity: number;
  neurotransmitter: string;
}

interface BrainRegion {
  id: string;
  name: string;
  position: THREE.Vector3;
  size: number;
  activity: number;
  neurons: Neuron[];
  color: string;
}

interface NeurotransmitterLevel {
  dopamine: number;
  serotonin: number;
  gaba: number;
  glutamate: number;
  acetylcholine: number;
}

interface NeuralVisualizationProps {
  realTimeData?: boolean;
  cognitiveLoad?: number;
  emotionalState?: string;
  onRegionClick?: (regionId: string) => void;
  onNeuronClick?: (neuronId: string) => void;
}

function NeuronComponent({
  neuron,
  onClick,
}: {
  neuron: Neuron;
  onClick?: (neuronId: string) => void;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    if (meshRef.current) {
      // Animate based on activity level
      const scale = 1 + neuron.activity * 0.5;
      const rotationSpeed = neuron.activity * 2;

      meshRef.current.scale.setScalar(scale);
      meshRef.current.rotation.y += rotationSpeed * 0.01;

      // Firing animation
      if (neuron.firing) {
        meshRef.current.material.emissiveIntensity =
          Math.sin(state.clock.elapsedTime * 10) * 0.5 + 0.5;
      } else {
        meshRef.current.material.emissiveIntensity = neuron.activity * 0.3;
      }
    }
  });

  const neurotransmitterColors = {
    dopamine: "#ff69b4",
    serotonin: "#87ceeb",
    gaba: "#98fb98",
    glutamate: "#ffdab9",
    acetylcholine: "#dda0dd",
  };

  return (
    <Sphere
      ref={meshRef}
      position={neuron.position.toArray()}
      args={[0.05, 16, 16]}
      onPointerEnter={() => setHovered(true)}
      onPointerLeave={() => setHovered(false)}
      onClick={() => onClick?.(neuron.id)}
    >
      <MeshDistortMaterial
        color={
          neurotransmitterColors[
            neuron.neurotransmitter as keyof typeof neurotransmitterColors
          ]
        }
        attach="material"
        distort={hovered ? 0.4 : 0.1}
        speed={neuron.activity * 5}
        roughness={0.2}
        metalness={0.8}
        emissive={
          neurotransmitterColors[
            neuron.neurotransmitter as keyof typeof neurotransmitterColors
          ]
        }
        emissiveIntensity={neuron.activity * 0.3}
      />
      {hovered && (
        <Text
          position={[0, 0.2, 0]}
          fontSize={0.03}
          color="white"
          anchorX="center"
          anchorY="middle"
        >
          {neuron.neurotransmitter}
        </Text>
      )}
    </Sphere>
  );
}

function SynapseComponent({
  synapse,
  neurons,
}: {
  synapse: Synapse;
  neurons: Neuron[];
}) {
  const fromNeuron = neurons.find((n) => n.id === synapse.from);
  const toNeuron = neurons.find((n) => n.id === synapse.to);

  if (!fromNeuron || !toNeuron) return null;

  const points = [fromNeuron.position, toNeuron.position];
  const lineGeometry = new THREE.BufferGeometry().setFromPoints(points);

  return (
    <line geometry={lineGeometry}>
      <lineBasicMaterial
        color={synapse.activity > 0.5 ? "#ffff00" : "#4169e1"}
        linewidth={synapse.strength * 3}
        transparent
        opacity={synapse.activity}
      />
    </line>
  );
}

function BrainRegionComponent({
  region,
  onClick,
  showNeurons = true,
}: {
  region: BrainRegion;
  onClick?: (regionId: string) => void;
  showNeurons?: boolean;
}) {
  const groupRef = useRef<THREE.Group>(null);
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    if (groupRef.current) {
      const pulseFactor =
        1 + Math.sin(state.clock.elapsedTime * region.activity * 2) * 0.1;
      groupRef.current.scale.setScalar(pulseFactor);
    }
  });

  return (
    <group ref={groupRef} position={region.position.toArray()}>
      {/* Region boundary */}
      <Sphere
        args={[region.size, 32, 32]}
        onPointerEnter={() => setHovered(true)}
        onPointerLeave={() => setHovered(false)}
        onClick={() => onClick?.(region.id)}
      >
        <meshPhongMaterial
          color={region.color}
          transparent
          opacity={hovered ? 0.3 : 0.1}
          wireframe={hovered}
        />
      </Sphere>

      {/* Region label */}
      <Text
        position={[0, region.size + 0.2, 0]}
        fontSize={0.1}
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        {region.name}
      </Text>

      {/* Neurons within region */}
      {showNeurons &&
        region.neurons.map((neuron) => (
          <NeuronComponent key={neuron.id} neuron={neuron} />
        ))}
    </group>
  );
}

function NeuralScene({
  regions,
  synapses,
  showConnections,
  viewMode,
}: {
  regions: BrainRegion[];
  synapses: Synapse[];
  showConnections: boolean;
  viewMode: string;
}) {
  const allNeurons = regions.flatMap((region) => region.neurons);

  return (
    <>
      <Environment preset="studio" />
      <ambientLight intensity={0.3} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#ffffff" />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#4169e1" />

      {/* Brain regions */}
      {regions.map((region) => (
        <BrainRegionComponent
          key={region.id}
          region={region}
          showNeurons={viewMode === "detailed"}
        />
      ))}

      {/* Synaptic connections */}
      {showConnections &&
        synapses.map((synapse, index) => (
          <SynapseComponent
            key={`${synapse.from}-${synapse.to}-${index}`}
            synapse={synapse}
            neurons={allNeurons}
          />
        ))}

      <OrbitControls
        enablePan={true}
        enableZoom={true}
        enableRotate={true}
        autoRotate={false}
        maxDistance={10}
        minDistance={2}
      />
    </>
  );
}

export default function NeuralVisualization({
  realTimeData = true,
  cognitiveLoad = 0.5,
  emotionalState = "neutral",
  onRegionClick,
  onNeuronClick,
}: NeuralVisualizationProps) {
  const [isPlaying, setIsPlaying] = useState(realTimeData);
  const [showConnections, setShowConnections] = useState(true);
  const [viewMode, setViewMode] = useState("overview");
  const [selectedRegion, setSelectedRegion] = useState<string | null>(null);
  const [neurotransmitterLevels, setNeurotransmitterLevels] =
    useState<NeurotransmitterLevel>({
      dopamine: 0.6,
      serotonin: 0.7,
      gaba: 0.4,
      glutamate: 0.8,
      acetylcholine: 0.5,
    });

  // Generate brain regions with neurons
  const brainRegions = useMemo((): BrainRegion[] => {
    const regions = [
      {
        id: "prefrontal",
        name: "Prefrontal Cortex",
        position: new THREE.Vector3(0, 1, 1),
        size: 0.8,
        color: "#dbc0dc",
        baseActivity: 0.7,
      },
      {
        id: "hippocampus",
        name: "Hippocampus",
        position: new THREE.Vector3(-1.2, -0.3, 0),
        size: 0.6,
        color: "#98fb98",
        baseActivity: 0.6,
      },
      {
        id: "amygdala",
        name: "Amygdala",
        position: new THREE.Vector3(-0.8, -0.5, -0.8),
        size: 0.4,
        color: "#ffb6c1",
        baseActivity: 0.4,
      },
      {
        id: "visual",
        name: "Visual Cortex",
        position: new THREE.Vector3(0, -0.8, -1.5),
        size: 0.7,
        color: "#ffe4b5",
        baseActivity: 0.5,
      },
      {
        id: "motor",
        name: "Motor Cortex",
        position: new THREE.Vector3(1.2, 0.5, 0.2),
        size: 0.6,
        color: "#add8e6",
        baseActivity: 0.3,
      },
    ];

    return regions.map((region) => {
      const neurons: Neuron[] = [];
      const neuronCount = Math.floor(Math.random() * 20) + 10;

      for (let i = 0; i < neuronCount; i++) {
        const localPos = new THREE.Vector3(
          (Math.random() - 0.5) * region.size,
          (Math.random() - 0.5) * region.size,
          (Math.random() - 0.5) * region.size,
        );

        const globalPos = region.position.clone().add(localPos);

        const neurotransmitters = [
          "dopamine",
          "serotonin",
          "gaba",
          "glutamate",
          "acetylcholine",
        ];
        const randomNT =
          neurotransmitters[
            Math.floor(Math.random() * neurotransmitters.length)
          ];

        neurons.push({
          id: `${region.id}-neuron-${i}`,
          position: globalPos,
          activity: region.baseActivity + (Math.random() - 0.5) * 0.3,
          neurotransmitter: randomNT,
          connections: [],
          region: region.id,
          firing: Math.random() > 0.8,
        });
      }

      return {
        ...region,
        activity: region.baseActivity + cognitiveLoad * 0.3,
        neurons,
      };
    });
  }, [cognitiveLoad]);

  // Generate synaptic connections
  const synapses = useMemo((): Synapse[] => {
    const connections: Synapse[] = [];
    const allNeurons = brainRegions.flatMap((region) => region.neurons);

    // Create inter-regional connections
    for (let i = 0; i < allNeurons.length; i++) {
      const neuron1 = allNeurons[i];
      for (let j = i + 1; j < allNeurons.length; j++) {
        const neuron2 = allNeurons[j];

        if (neuron1.region !== neuron2.region && Math.random() > 0.95) {
          connections.push({
            from: neuron1.id,
            to: neuron2.id,
            strength: Math.random(),
            activity: Math.random(),
            neurotransmitter: neuron1.neurotransmitter,
          });
        }
      }
    }

    return connections;
  }, [brainRegions]);

  // Update neural activity based on cognitive load and emotional state
  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        // Simulate real-time neural activity updates
        // This would connect to actual EEG data in a real implementation
        setNeurotransmitterLevels((prev) => ({
          dopamine: Math.max(
            0,
            Math.min(1, prev.dopamine + (Math.random() - 0.5) * 0.1),
          ),
          serotonin: Math.max(
            0,
            Math.min(1, prev.serotonin + (Math.random() - 0.5) * 0.1),
          ),
          gaba: Math.max(
            0,
            Math.min(1, prev.gaba + (Math.random() - 0.5) * 0.1),
          ),
          glutamate: Math.max(
            0,
            Math.min(1, prev.glutamate + (Math.random() - 0.5) * 0.1),
          ),
          acetylcholine: Math.max(
            0,
            Math.min(1, prev.acetylcholine + (Math.random() - 0.5) * 0.1),
          ),
        }));
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isPlaying]);

  return (
    <div className="space-y-6">
      {/* Control Panel */}
      <Card className="cognitive-enhancement-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Neural Visualization Controls
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Real-time Updates</span>
                <Switch checked={isPlaying} onCheckedChange={setIsPlaying} />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Show Connections</span>
                <Switch
                  checked={showConnections}
                  onCheckedChange={setShowConnections}
                />
              </div>

              <div className="space-y-2">
                <span className="text-sm font-medium">View Mode</span>
                <Select value={viewMode} onValueChange={setViewMode}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="overview">Overview</SelectItem>
                    <SelectItem value="detailed">Detailed</SelectItem>
                    <SelectItem value="regions">Regions Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <span className="text-sm font-medium mb-2 block">
                  Cognitive Load
                </span>
                <div className="text-2xl font-bold text-orange-600">
                  {Math.round(cognitiveLoad * 100)}%
                </div>
              </div>

              <div>
                <span className="text-sm font-medium mb-2 block">
                  Emotional State
                </span>
                <Badge
                  className={`
                    ${
                      emotionalState === "calm"
                        ? "bg-green-100 text-green-800"
                        : emotionalState === "focused"
                          ? "bg-blue-100 text-blue-800"
                          : emotionalState === "stressed"
                            ? "bg-red-100 text-red-800"
                            : "bg-gray-100 text-gray-800"
                    }
                  `}
                >
                  {emotionalState}
                </Badge>
              </div>
            </div>

            <div className="space-y-2">
              <span className="text-sm font-medium">Brain Regions</span>
              <div className="flex flex-wrap gap-1">
                {brainRegions.map((region) => (
                  <Badge
                    key={region.id}
                    variant={
                      selectedRegion === region.id ? "default" : "outline"
                    }
                    className="cursor-pointer"
                    onClick={() => {
                      setSelectedRegion(
                        selectedRegion === region.id ? null : region.id,
                      );
                      onRegionClick?.(region.id);
                    }}
                  >
                    {region.name.split(" ")[0]}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 3D Neural Visualization */}
      <Card className="cognitive-enhancement-card">
        <CardContent className="p-0">
          <div className="w-full h-[600px] bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 rounded-lg overflow-hidden">
            <Canvas
              camera={{
                position: [3, 3, 5],
                fov: 60,
              }}
              style={{ background: "transparent" }}
            >
              <NeuralScene
                regions={brainRegions}
                synapses={synapses}
                showConnections={showConnections}
                viewMode={viewMode}
              />
            </Canvas>
          </div>
        </CardContent>
      </Card>

      {/* Neurotransmitter Levels */}
      <Card className="cognitive-enhancement-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Neurotransmitter Simulation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-5 gap-4">
            {Object.entries(neurotransmitterLevels).map(
              ([neurotransmitter, level]) => (
                <div
                  key={neurotransmitter}
                  className="neurotransmitter-panel p-4 rounded-lg"
                >
                  <div className="text-center">
                    <div className="text-lg font-bold capitalize mb-2">
                      {neurotransmitter}
                    </div>
                    <div className="text-2xl font-bold mb-2">
                      {Math.round(level * 100)}%
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                      <motion.div
                        className={`h-2 rounded-full ${
                          neurotransmitter === "dopamine"
                            ? "bg-pink-400"
                            : neurotransmitter === "serotonin"
                              ? "bg-blue-400"
                              : neurotransmitter === "gaba"
                                ? "bg-green-400"
                                : neurotransmitter === "glutamate"
                                  ? "bg-orange-400"
                                  : "bg-purple-400"
                        } neurotransmitter-flow`}
                        style={{ width: `${level * 100}%` }}
                        animate={{ opacity: [0.6, 1, 0.6] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      />
                    </div>
                    <div className="text-xs text-gray-600 capitalize">
                      {neurotransmitter === "dopamine"
                        ? "Reward & Motivation"
                        : neurotransmitter === "serotonin"
                          ? "Mood & Well-being"
                          : neurotransmitter === "gaba"
                            ? "Calm & Relaxation"
                            : neurotransmitter === "glutamate"
                              ? "Learning & Memory"
                              : "Attention & Focus"}
                    </div>
                  </div>
                </div>
              ),
            )}
          </div>
        </CardContent>
      </Card>

      {/* Selected Region Details */}
      <AnimatePresence>
        {selectedRegion && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <Card className="cognitive-enhancement-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Layers className="h-5 w-5" />
                  {brainRegions.find((r) => r.id === selectedRegion)?.name}{" "}
                  Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                {(() => {
                  const region = brainRegions.find(
                    (r) => r.id === selectedRegion,
                  );
                  if (!region) return null;

                  return (
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-2">
                            Region Activity
                          </h4>
                          <div className="flex items-center gap-2">
                            <div className="flex-1 bg-gray-200 rounded-full h-3">
                              <div
                                className="bg-blue-400 h-3 rounded-full neural-pulse"
                                style={{ width: `${region.activity * 100}%` }}
                              />
                            </div>
                            <span className="text-sm font-medium">
                              {Math.round(region.activity * 100)}%
                            </span>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Active Neurons</h4>
                          <div className="text-2xl font-bold text-blue-600">
                            {
                              region.neurons.filter((n) => n.activity > 0.5)
                                .length
                            }
                          </div>
                          <div className="text-sm text-gray-600">
                            of {region.neurons.length} total
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-2">
                            Primary Functions
                          </h4>
                          <div className="text-sm text-gray-600">
                            {selectedRegion === "prefrontal" &&
                              "Executive function, decision making, working memory"}
                            {selectedRegion === "hippocampus" &&
                              "Memory formation, spatial navigation, learning"}
                            {selectedRegion === "amygdala" &&
                              "Emotion processing, fear response, emotional memory"}
                            {selectedRegion === "visual" &&
                              "Visual processing, pattern recognition, spatial awareness"}
                            {selectedRegion === "motor" &&
                              "Movement control, motor learning, coordination"}
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">
                            Neurotransmitter Distribution
                          </h4>
                          <div className="flex flex-wrap gap-1">
                            {Object.entries(
                              region.neurons.reduce(
                                (acc, neuron) => {
                                  acc[neuron.neurotransmitter] =
                                    (acc[neuron.neurotransmitter] || 0) + 1;
                                  return acc;
                                },
                                {} as Record<string, number>,
                              ),
                            ).map(([nt, count]) => (
                              <Badge
                                key={nt}
                                variant="outline"
                                className="text-xs"
                              >
                                {nt}: {count}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
