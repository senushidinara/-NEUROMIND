import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { 
  Bot, 
  User, 
  Send, 
  Mic, 
  MicOff, 
  Sparkles, 
  Brain, 
  Zap,
  MessageCircle,
  X,
  Volume2,
  VolumeX
} from 'lucide-react';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: number;
  typing?: boolean;
  suggestions?: string[];
}

interface AIChatbotProps {
  isOpen: boolean;
  onClose: () => void;
  onSuggestion?: (suggestion: string) => void;
}

export default function AIChatbot({ isOpen, onClose, onSuggestion }: AIChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "Hello! I'm your AI assistant. I can help you with cognitive assessments, wellness recommendations, brain training tips, and more. What would you like to explore today?",
      sender: 'ai',
      timestamp: Date.now(),
      suggestions: [
        "Start a cognitive assessment",
        "Recommend meditation exercises",
        "Explain my brain map results",
        "Tips for better focus"
      ]
    }
  ]);
  
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // AI response templates
  const aiResponses = {
    greeting: [
      "Hello! I'm here to help you optimize your cognitive performance. What can I assist you with?",
      "Hi there! Ready to explore your brain's potential today?",
      "Welcome back! How can I support your cognitive health journey?"
    ],
    assessment: [
      "Great choice! Cognitive assessments help track your mental performance. I recommend starting with the Reaction Time test - it's quick and gives immediate insights into your processing speed.",
      "Let's get your brain working! The N-Back memory test is excellent for working memory training. Would you like me to guide you through it?",
      "Assessments are key to understanding your cognitive baseline. Based on your previous sessions, I suggest focusing on spatial memory today."
    ],
    meditation: [
      "Meditation is fantastic for cognitive health! For beginners, I recommend starting with our 5-minute focused breathing exercise. It helps improve attention and reduces stress.",
      "Perfect timing for mindfulness! Try our guided meditation with binaural beats - it's designed to enhance alpha brain waves associated with relaxation and creativity.",
      "Research shows regular meditation can increase gray matter density. Our yoga flow combines movement with mindfulness for maximum cognitive benefits."
    ],
    brain: [
      "Your brain map shows interesting patterns! The prefrontal cortex activity suggests strong executive function, while the hippocampus engagement indicates good memory formation.",
      "I notice increased activity in your motor cortex during today's session. This suggests good mind-body coordination. Have you been practicing any physical exercises?",
      "The visual cortex activation patterns look optimal! This correlates well with your spatial memory scores. Keep up the visual training exercises."
    ],
    focus: [
      "For better focus, try the Pomodoro technique: 25 minutes of concentrated work followed by 5-minute breaks. Our app can track this for you!",
      "Cognitive load theory suggests breaking complex tasks into smaller chunks. I can help you design a personalized focus training program.",
      "Your attention span data shows improvement! Consider adding working memory exercises to further enhance your sustained attention abilities."
    ],
    default: [
      "That's an interesting question! Based on neuroscience research, I'd recommend exploring our interactive brain training modules.",
      "I can provide insights based on your cognitive profile. Would you like me to analyze your recent assessment results?",
      "Let me think about that... Based on your usage patterns, I have some personalized recommendations for you."
    ]
  };

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const playSound = (type: 'send' | 'receive' | 'notification') => {
    if (!soundEnabled) return;
    
    // Create audio context for sound effects
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    if (type === 'send') {
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 0.1);
    } else if (type === 'receive') {
      oscillator.frequency.setValueAtTime(400, audioContext.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(600, audioContext.currentTime + 0.15);
    } else {
      oscillator.frequency.setValueAtTime(600, audioContext.currentTime);
    }
    
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.2);
  };

  const getAIResponse = (userMessage: string): { content: string; suggestions?: string[] } => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('hello') || message.includes('hi') || message.includes('hey')) {
      return {
        content: aiResponses.greeting[Math.floor(Math.random() * aiResponses.greeting.length)],
        suggestions: ["Tell me about assessments", "Show wellness options", "Explain brain mapping"]
      };
    }
    
    if (message.includes('assessment') || message.includes('test') || message.includes('cognitive')) {
      return {
        content: aiResponses.assessment[Math.floor(Math.random() * aiResponses.assessment.length)],
        suggestions: ["Start reaction time test", "Try memory assessment", "View my progress"]
      };
    }
    
    if (message.includes('meditation') || message.includes('mindfulness') || message.includes('relax')) {
      return {
        content: aiResponses.meditation[Math.floor(Math.random() * aiResponses.meditation.length)],
        suggestions: ["5-min meditation", "Breathing exercise", "Yoga flow"]
      };
    }
    
    if (message.includes('brain') || message.includes('map') || message.includes('neuron')) {
      return {
        content: aiResponses.brain[Math.floor(Math.random() * aiResponses.brain.length)],
        suggestions: ["Explore brain regions", "View EEG patterns", "Learn about plasticity"]
      };
    }
    
    if (message.includes('focus') || message.includes('attention') || message.includes('concentrate')) {
      return {
        content: aiResponses.focus[Math.floor(Math.random() * aiResponses.focus.length)],
        suggestions: ["Focus training", "Attention exercises", "Productivity tips"]
      };
    }
    
    return {
      content: aiResponses.default[Math.floor(Math.random() * aiResponses.default.length)],
      suggestions: ["View recommendations", "Check progress", "Explore features"]
    };
  };

  const sendMessage = async () => {
    if (!inputValue.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: 'user',
      timestamp: Date.now()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);
    playSound('send');
    
    // Simulate typing delay
    setTimeout(() => {
      const aiResponse = getAIResponse(userMessage.content);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: aiResponse.content,
        sender: 'ai',
        timestamp: Date.now(),
        suggestions: aiResponse.suggestions
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
      playSound('receive');
    }, 1000 + Math.random() * 2000);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInputValue(suggestion);
    if (onSuggestion) {
      onSuggestion(suggestion);
    }
  };

  const startVoiceRecognition = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Voice recognition not supported in this browser');
      return;
    }
    
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    
    recognition.onstart = () => {
      setIsListening(true);
      playSound('notification');
    };
    
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInputValue(transcript);
      setIsListening(false);
    };
    
    recognition.onerror = () => {
      setIsListening(false);
    };
    
    recognition.onend = () => {
      setIsListening(false);
    };
    
    recognition.start();
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className="fixed bottom-4 right-4 z-50 w-96 h-[600px] max-w-[calc(100vw-2rem)] max-h-[calc(100vh-2rem)]"
    >
      <Card className="h-full backdrop-blur-xl bg-white/10 dark:bg-black/10 border border-white/20 shadow-2xl overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-sm border-b border-white/10">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-white">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                <Bot className="h-4 w-4 text-white" />
              </div>
              AI Assistant
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-2 h-2 bg-green-400 rounded-full"
              />
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSoundEnabled(!soundEnabled)}
                className="text-white hover:bg-white/10"
              >
                {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="text-white hover:bg-white/10"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="p-0 h-full flex flex-col">
          <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
            <div className="space-y-4">
              <AnimatePresence>
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                    className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`flex items-start gap-2 max-w-[80%] ${message.sender === 'user' ? 'flex-row-reverse' : ''}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        message.sender === 'user' 
                          ? 'bg-gradient-to-r from-blue-500 to-cyan-500' 
                          : 'bg-gradient-to-r from-purple-500 to-pink-500'
                      }`}>
                        {message.sender === 'user' ? (
                          <User className="h-4 w-4 text-white" />
                        ) : (
                          <Bot className="h-4 w-4 text-white" />
                        )}
                      </div>
                      
                      <div className={`p-3 rounded-2xl backdrop-blur-sm ${
                        message.sender === 'user'
                          ? 'bg-blue-500/20 border border-blue-500/30 text-white'
                          : 'bg-white/10 border border-white/20 text-white'
                      }`}>
                        <p className="text-sm leading-relaxed">{message.content}</p>
                        
                        {message.suggestions && (
                          <div className="mt-3 flex flex-wrap gap-2">
                            {message.suggestions.map((suggestion, index) => (
                              <Badge
                                key={index}
                                variant="secondary"
                                className="cursor-pointer hover:bg-white/20 transition-colors text-xs bg-white/10 text-white border border-white/20"
                                onClick={() => handleSuggestionClick(suggestion)}
                              >
                                {suggestion}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              
              {isTyping && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex justify-start"
                >
                  <div className="flex items-start gap-2">
                    <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                      <Bot className="h-4 w-4 text-white" />
                    </div>
                    <div className="p-3 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20">
                      <div className="flex items-center gap-1">
                        <motion.div
                          animate={{ scale: [1, 1.2, 1] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: 0 }}
                          className="w-2 h-2 bg-purple-400 rounded-full"
                        />
                        <motion.div
                          animate={{ scale: [1, 1.2, 1] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }}
                          className="w-2 h-2 bg-pink-400 rounded-full"
                        />
                        <motion.div
                          animate={{ scale: [1, 1.2, 1] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: 0.4 }}
                          className="w-2 h-2 bg-purple-400 rounded-full"
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          </ScrollArea>
          
          <div className="p-4 border-t border-white/10 bg-black/10 backdrop-blur-sm">
            <div className="flex items-center gap-2">
              <Input
                ref={inputRef}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="Ask me anything about cognitive health..."
                className="flex-1 bg-white/10 border-white/20 text-white placeholder:text-white/60 focus:ring-purple-500/50"
              />
              <Button
                variant="ghost"
                size="sm"
                onClick={startVoiceRecognition}
                disabled={isListening}
                className={`text-white hover:bg-white/10 ${isListening ? 'animate-pulse' : ''}`}
              >
                {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              </Button>
              <Button
                onClick={sendMessage}
                disabled={!inputValue.trim() || isTyping}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
                size="sm"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
