import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Cloud,
  Cpu,
  Database,
  Globe,
  Zap,
  Activity,
  BarChart3,
  TrendingUp,
  Timer,
  Shield,
  Lock,
  Wifi,
  Server,
  HardDrive,
  Memory,
  Network,
  AlertTriangle,
  CheckCircle,
  Circle,
  ArrowUp,
  ArrowDown,
  RefreshCw,
  Settings,
  Monitor,
  Smartphone,
  Layers,
  GitBranch,
  Package,
  Terminal,
  Code,
  Play,
  Pause,
  Square,
  RotateCw,
  Gauge,
  Target,
  Brain,
  Eye,
  Heart
} from "lucide-react";

interface ServerlessFunction {
  id: string;
  name: string;
  runtime: 'python' | 'nodejs' | 'go' | 'rust';
  provider: 'aws_lambda' | 'modal' | 'vercel' | 'netlify' | 'gcp_functions';
  status: 'active' | 'idle' | 'scaling' | 'error' | 'deploying';
  invocations: number;
  avgDuration: number;
  memoryUsage: number;
  coldStarts: number;
  errorRate: number;
  lastDeployment: Date;
  scalingConfig: {
    minInstances: number;
    maxInstances: number;
    targetConcurrency: number;
    scaleUpDelay: number;
    scaleDownDelay: number;
  };
}

interface EdgeLocation {
  id: string;
  region: string;
  city: string;
  country: string;
  latency: number;
  requests: number;
  cacheHitRate: number;
  status: 'healthy' | 'degraded' | 'offline';
  services: string[];
  coordinates: [number, number];
}

interface RealTimeMetrics {
  timestamp: number;
  activeConnections: number;
  requestsPerSecond: number;
  responseTime: number;
  cpuUsage: number;
  memoryUsage: number;
  bandwidth: number;
  errorRate: number;
  throughput: number;
}

interface AIWorkload {
  id: string;
  type: 'cognitive_analysis' | 'neural_prediction' | 'biofeedback_processing' | 'vision_inference' | 'nlp_processing';
  model: string;
  inputSize: number;
  outputSize: number;
  latencyRequirement: number;
  accuracyTarget: number;
  scalingPattern: 'burst' | 'steady' | 'predictive';
  computeUnits: number;
  gpuRequired: boolean;
}

interface CloudProvider {
  name: string;
  services: {
    compute: string[];
    storage: string[];
    ai: string[];
    networking: string[];
  };
  regions: string[];
  pricing: {
    compute: number;
    storage: number;
    bandwidth: number;
  };
  features: string[];
}

export default function ServerlessInfrastructure() {
  const [serverlessFunctions, setServerlessFunctions] = useState<ServerlessFunction[]>([]);
  const [edgeLocations, setEdgeLocations] = useState<EdgeLocation[]>([]);
  const [realTimeMetrics, setRealTimeMetrics] = useState<RealTimeMetrics[]>([]);
  const [aiWorkloads, setAiWorkloads] = useState<AIWorkload[]>([]);
  const [cloudProviders, setCloudProviders] = useState<CloudProvider[]>([]);
  const [activeProvider, setActiveProvider] = useState<string>('aws');
  const [autoScaling, setAutoScaling] = useState<boolean>(true);
  const [edgeOptimization, setEdgeOptimization] = useState<boolean>(true);
  const [monitoringInterval, setMonitoringInterval] = useState<number>(5000);
  const [alertThresholds, setAlertThresholds] = useState({
    responseTime: 500,
    errorRate: 5,
    cpuUsage: 80,
    memoryUsage: 85
  });

  const metricsInterval = useRef<NodeJS.Timeout>();
  const scalingEngine = useRef<any>();

  // Initialize serverless functions
  useEffect(() => {
    const functions: ServerlessFunction[] = [
      {
        id: 'cognitive-analyzer',
        name: 'Cognitive Analysis Engine',
        runtime: 'python',
        provider: 'modal',
        status: 'active',
        invocations: 15847,
        avgDuration: 245,
        memoryUsage: 1024,
        coldStarts: 23,
        errorRate: 0.02,
        lastDeployment: new Date(Date.now() - 3600000),
        scalingConfig: {
          minInstances: 2,
          maxInstances: 50,
          targetConcurrency: 10,
          scaleUpDelay: 30,
          scaleDownDelay: 300
        }
      },
      {
        id: 'neural-predictor',
        name: 'Neural Prediction Service',
        runtime: 'python',
        provider: 'aws_lambda',
        status: 'scaling',
        invocations: 8432,
        avgDuration: 180,
        memoryUsage: 2048,
        coldStarts: 45,
        errorRate: 0.01,
        lastDeployment: new Date(Date.now() - 7200000),
        scalingConfig: {
          minInstances: 1,
          maxInstances: 20,
          targetConcurrency: 5,
          scaleUpDelay: 60,
          scaleDownDelay: 600
        }
      },
      {
        id: 'biofeedback-processor',
        name: 'Biofeedback Data Processor',
        runtime: 'nodejs',
        provider: 'vercel',
        status: 'active',
        invocations: 23658,
        avgDuration: 120,
        memoryUsage: 512,
        coldStarts: 156,
        errorRate: 0.03,
        lastDeployment: new Date(Date.now() - 1800000),
        scalingConfig: {
          minInstances: 3,
          maxInstances: 30,
          targetConcurrency: 15,
          scaleUpDelay: 20,
          scaleDownDelay: 180
        }
      },
      {
        id: 'vision-inference',
        name: 'Computer Vision Inference',
        runtime: 'python',
        provider: 'gcp_functions',
        status: 'active',
        invocations: 5674,
        avgDuration: 320,
        memoryUsage: 4096,
        coldStarts: 12,
        errorRate: 0.005,
        lastDeployment: new Date(Date.now() - 10800000),
        scalingConfig: {
          minInstances: 1,
          maxInstances: 15,
          targetConcurrency: 3,
          scaleUpDelay: 45,
          scaleDownDelay: 900
        }
      },
      {
        id: 'nlp-processor',
        name: 'Natural Language Processing',
        runtime: 'python',
        provider: 'modal',
        status: 'idle',
        invocations: 3241,
        avgDuration: 290,
        memoryUsage: 1536,
        coldStarts: 67,
        errorRate: 0.015,
        lastDeployment: new Date(Date.now() - 14400000),
        scalingConfig: {
          minInstances: 0,
          maxInstances: 25,
          targetConcurrency: 8,
          scaleUpDelay: 90,
          scaleDownDelay: 600
        }
      }
    ];

    setServerlessFunctions(functions);
  }, []);

  // Initialize edge locations
  useEffect(() => {
    const locations: EdgeLocation[] = [
      {
        id: 'us-east-1',
        region: 'US East',
        city: 'Virginia',
        country: 'USA',
        latency: 28,
        requests: 45623,
        cacheHitRate: 87.3,
        status: 'healthy',
        services: ['CDN', 'Compute', 'AI Inference'],
        coordinates: [39.0458, -77.5311]
      },
      {
        id: 'us-west-2',
        region: 'US West',
        city: 'Oregon',
        country: 'USA',
        latency: 35,
        requests: 32145,
        cacheHitRate: 84.7,
        status: 'healthy',
        services: ['CDN', 'Compute', 'Storage'],
        coordinates: [45.8696, -119.6880]
      },
      {
        id: 'eu-west-1',
        region: 'Europe',
        city: 'Ireland',
        country: 'Ireland',
        latency: 42,
        requests: 28967,
        cacheHitRate: 91.2,
        status: 'healthy',
        services: ['CDN', 'Compute', 'AI Inference', 'Analytics'],
        coordinates: [53.4084, -8.2439]
      },
      {
        id: 'ap-southeast-1',
        region: 'Asia Pacific',
        city: 'Singapore',
        country: 'Singapore',
        latency: 58,
        requests: 18743,
        cacheHitRate: 89.5,
        status: 'degraded',
        services: ['CDN', 'Storage'],
        coordinates: [1.3521, 103.8198]
      },
      {
        id: 'ap-northeast-1',
        region: 'Asia Pacific',
        city: 'Tokyo',
        country: 'Japan',
        latency: 72,
        requests: 15234,
        cacheHitRate: 82.1,
        status: 'healthy',
        services: ['CDN', 'Compute', 'AI Inference'],
        coordinates: [35.6762, 139.6503]
      }
    ];

    setEdgeLocations(locations);
  }, []);

  // Initialize AI workloads
  useEffect(() => {
    const workloads: AIWorkload[] = [
      {
        id: 'cognitive-analysis',
        type: 'cognitive_analysis',
        model: 'transformer-xl-cognitive-v2',
        inputSize: 1024,
        outputSize: 256,
        latencyRequirement: 200,
        accuracyTarget: 94.5,
        scalingPattern: 'burst',
        computeUnits: 8,
        gpuRequired: true
      },
      {
        id: 'neural-prediction',
        type: 'neural_prediction',
        model: 'lstm-neural-dynamics-v3',
        inputSize: 512,
        outputSize: 128,
        latencyRequirement: 150,
        accuracyTarget: 92.8,
        scalingPattern: 'steady',
        computeUnits: 4,
        gpuRequired: false
      },
      {
        id: 'biofeedback-processing',
        type: 'biofeedback_processing',
        model: 'cnn-biometric-classifier-v4',
        inputSize: 2048,
        outputSize: 64,
        latencyRequirement: 100,
        accuracyTarget: 96.2,
        scalingPattern: 'predictive',
        computeUnits: 6,
        gpuRequired: true
      },
      {
        id: 'vision-inference',
        type: 'vision_inference',
        model: 'efficientnet-emotion-v5',
        inputSize: 224*224*3,
        outputSize: 16,
        latencyRequirement: 300,
        accuracyTarget: 89.7,
        scalingPattern: 'burst',
        computeUnits: 12,
        gpuRequired: true
      }
    ];

    setAiWorkloads(workloads);
  }, []);

  // Initialize cloud providers
  useEffect(() => {
    const providers: CloudProvider[] = [
      {
        name: 'AWS',
        services: {
          compute: ['Lambda', 'EC2', 'Fargate', 'ECS'],
          storage: ['S3', 'EFS', 'DynamoDB'],
          ai: ['SageMaker', 'Bedrock', 'Rekognition', 'Comprehend'],
          networking: ['CloudFront', 'API Gateway', 'VPC']
        },
        regions: ['us-east-1', 'us-west-2', 'eu-west-1', 'ap-southeast-1'],
        pricing: {
          compute: 0.0000166667,
          storage: 0.023,
          bandwidth: 0.09
        },
        features: ['Auto Scaling', 'Spot Instances', 'Reserved Capacity', 'Multi-AZ']
      },
      {
        name: 'Modal',
        services: {
          compute: ['Serverless GPU', 'Container Functions', 'Scheduled Jobs'],
          storage: ['Volumes', 'Shared Storage'],
          ai: ['GPU Inference', 'Model Serving', 'Training'],
          networking: ['Load Balancing', 'Custom Domains']
        },
        regions: ['us-east', 'us-west', 'eu-west'],
        pricing: {
          compute: 0.0001,
          storage: 0.1,
          bandwidth: 0.05
        },
        features: ['GPU Support', 'Cold Start Optimization', 'Developer Tools']
      },
      {
        name: 'Google Cloud',
        services: {
          compute: ['Cloud Functions', 'Cloud Run', 'Compute Engine'],
          storage: ['Cloud Storage', 'Firestore', 'BigQuery'],
          ai: ['Vertex AI', 'Vision API', 'Natural Language'],
          networking: ['Cloud CDN', 'Load Balancing', 'Cloud Armor']
        },
        regions: ['us-central1', 'us-west1', 'europe-west1', 'asia-southeast1'],
        pricing: {
          compute: 0.0000165,
          storage: 0.02,
          bandwidth: 0.08
        },
        features: ['Preemptible Instances', 'Global Load Balancing', 'BigQuery Analytics']
      }
    ];

    setCloudProviders(providers);
  }, []);

  // Real-time metrics collection
  useEffect(() => {
    metricsInterval.current = setInterval(() => {
      const newMetric: RealTimeMetrics = {
        timestamp: Date.now(),
        activeConnections: Math.floor(Math.random() * 1000) + 500,
        requestsPerSecond: Math.floor(Math.random() * 500) + 200,
        responseTime: Math.floor(Math.random() * 200) + 50,
        cpuUsage: Math.floor(Math.random() * 40) + 30,
        memoryUsage: Math.floor(Math.random() * 30) + 40,
        bandwidth: Math.floor(Math.random() * 100) + 50,
        errorRate: Math.random() * 2,
        throughput: Math.floor(Math.random() * 1000) + 500
      };

      setRealTimeMetrics(prev => [newMetric, ...prev.slice(0, 59)]);

      // Trigger auto-scaling if needed
      if (autoScaling) {
        checkAndScale(newMetric);
      }
    }, monitoringInterval);

    return () => {
      if (metricsInterval.current) {
        clearInterval(metricsInterval.current);
      }
    };
  }, [monitoringInterval, autoScaling]);

  const checkAndScale = useCallback((metrics: RealTimeMetrics) => {
    const shouldScaleUp = 
      metrics.responseTime > alertThresholds.responseTime ||
      metrics.cpuUsage > alertThresholds.cpuUsage ||
      metrics.memoryUsage > alertThresholds.memoryUsage;

    const shouldScaleDown = 
      metrics.responseTime < alertThresholds.responseTime * 0.5 &&
      metrics.cpuUsage < alertThresholds.cpuUsage * 0.3 &&
      metrics.memoryUsage < alertThresholds.memoryUsage * 0.3;

    if (shouldScaleUp) {
      scaleUp();
    } else if (shouldScaleDown) {
      scaleDown();
    }
  }, [alertThresholds]);

  const scaleUp = useCallback(() => {
    setServerlessFunctions(prev => 
      prev.map(func => ({
        ...func,
        status: 'scaling' as const,
        scalingConfig: {
          ...func.scalingConfig,
          minInstances: Math.min(func.scalingConfig.maxInstances, func.scalingConfig.minInstances + 1)
        }
      }))
    );

    setTimeout(() => {
      setServerlessFunctions(prev => 
        prev.map(func => ({
          ...func,
          status: 'active' as const
        }))
      );
    }, 5000);
  }, []);

  const scaleDown = useCallback(() => {
    setServerlessFunctions(prev => 
      prev.map(func => ({
        ...func,
        scalingConfig: {
          ...func.scalingConfig,
          minInstances: Math.max(0, func.scalingConfig.minInstances - 1)
        }
      }))
    );
  }, []);

  const deployFunction = useCallback((functionId: string) => {
    setServerlessFunctions(prev => 
      prev.map(func => 
        func.id === functionId 
          ? { ...func, status: 'deploying', lastDeployment: new Date() }
          : func
      )
    );

    setTimeout(() => {
      setServerlessFunctions(prev => 
        prev.map(func => 
          func.id === functionId 
            ? { ...func, status: 'active' }
            : func
        )
      );
    }, 10000);
  }, []);

  const getStatusColor = (status: string) => {
    const colors = {
      active: 'bg-green-100 text-green-800 border-green-200',
      idle: 'bg-gray-100 text-gray-800 border-gray-200',
      scaling: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      error: 'bg-red-100 text-red-800 border-red-200',
      deploying: 'bg-blue-100 text-blue-800 border-blue-200',
      healthy: 'bg-green-100 text-green-800 border-green-200',
      degraded: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      offline: 'bg-red-100 text-red-800 border-red-200'
    };
    return colors[status as keyof typeof colors] || colors.idle;
  };

  const getProviderIcon = (provider: string) => {
    const icons = {
      aws_lambda: Cloud,
      modal: Zap,
      vercel: Globe,
      netlify: Network,
      gcp_functions: Database
    };
    return icons[provider as keyof typeof icons] || Cloud;
  };

  const getCurrentMetrics = () => {
    return realTimeMetrics.length > 0 ? realTimeMetrics[0] : null;
  };

  return (
    <div className="space-y-6">
      {/* Infrastructure Overview */}
      <Card className="bg-gradient-to-br from-blue-50/80 to-indigo-50/80 backdrop-blur-sm border-blue-200/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-blue-900">
              <Cloud className="w-5 h-5" />
              Serverless Cloud Infrastructure
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge className="bg-green-100 text-green-800 border-green-200">
                <CheckCircle className="w-3 h-3 mr-1" />
                Operational
              </Badge>
              <Button
                onClick={() => setAutoScaling(!autoScaling)}
                variant={autoScaling ? 'default' : 'outline'}
                size="sm"
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Target className="w-4 h-4 mr-1" />
                Auto-Scale: {autoScaling ? 'ON' : 'OFF'}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Real-time Metrics */}
            {getCurrentMetrics() && (
              <>
                <div className="bg-white/60 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Activity className="w-4 h-4 text-green-500" />
                    <span className="font-medium text-gray-900">Active Connections</span>
                  </div>
                  <div className="text-2xl font-bold text-gray-900">
                    {getCurrentMetrics()!.activeConnections.toLocaleString()}
                  </div>
                  <div className="text-sm text-green-600">Live users</div>
                </div>

                <div className="bg-white/60 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Gauge className="w-4 h-4 text-blue-500" />
                    <span className="font-medium text-gray-900">Requests/sec</span>
                  </div>
                  <div className="text-2xl font-bold text-gray-900">
                    {getCurrentMetrics()!.requestsPerSecond}
                  </div>
                  <div className="text-sm text-blue-600">Real-time load</div>
                </div>

                <div className="bg-white/60 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Timer className="w-4 h-4 text-purple-500" />
                    <span className="font-medium text-gray-900">Response Time</span>
                  </div>
                  <div className="text-2xl font-bold text-gray-900">
                    {getCurrentMetrics()!.responseTime}ms
                  </div>
                  <div className={`text-sm ${getCurrentMetrics()!.responseTime > alertThresholds.responseTime ? 'text-red-600' : 'text-green-600'}`}>
                    {getCurrentMetrics()!.responseTime > alertThresholds.responseTime ? 'Above threshold' : 'Optimal'}
                  </div>
                </div>

                <div className="bg-white/60 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Cpu className="w-4 h-4 text-orange-500" />
                    <span className="font-medium text-gray-900">CPU Usage</span>
                  </div>
                  <div className="text-2xl font-bold text-gray-900">
                    {getCurrentMetrics()!.cpuUsage}%
                  </div>
                  <Progress value={getCurrentMetrics()!.cpuUsage} className="h-2 mt-2" />
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="functions" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5 bg-white/60 backdrop-blur-sm">
          <TabsTrigger value="functions">Serverless Functions</TabsTrigger>
          <TabsTrigger value="edge">Edge Locations</TabsTrigger>
          <TabsTrigger value="ai-workloads">AI Workloads</TabsTrigger>
          <TabsTrigger value="monitoring">Real-time Monitoring</TabsTrigger>
          <TabsTrigger value="providers">Cloud Providers</TabsTrigger>
        </TabsList>

        {/* Serverless Functions */}
        <TabsContent value="functions" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {serverlessFunctions.map((func) => {
              const ProviderIcon = getProviderIcon(func.provider);
              return (
                <motion.div
                  key={func.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="group"
                >
                  <Card className="bg-gradient-to-br from-white/80 to-gray-50/80 backdrop-blur-sm border-gray-200/30 hover:shadow-lg transition-all duration-300">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <ProviderIcon className="w-4 h-4 text-blue-600" />
                          <Badge className={getStatusColor(func.status)}>
                            {func.status.toUpperCase()}
                          </Badge>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {func.runtime.toUpperCase()}
                        </Badge>
                      </div>
                      <CardTitle className="text-lg">{func.name}</CardTitle>
                      <p className="text-sm text-gray-600">
                        Provider: {func.provider.replace('_', ' ').toUpperCase()}
                      </p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Performance Metrics */}
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-blue-50/60 p-3 rounded-lg">
                          <div className="text-xs text-blue-600 font-medium">Invocations</div>
                          <div className="text-lg font-bold text-blue-900">
                            {func.invocations.toLocaleString()}
                          </div>
                        </div>
                        <div className="bg-green-50/60 p-3 rounded-lg">
                          <div className="text-xs text-green-600 font-medium">Avg Duration</div>
                          <div className="text-lg font-bold text-green-900">
                            {func.avgDuration}ms
                          </div>
                        </div>
                        <div className="bg-purple-50/60 p-3 rounded-lg">
                          <div className="text-xs text-purple-600 font-medium">Memory</div>
                          <div className="text-lg font-bold text-purple-900">
                            {func.memoryUsage}MB
                          </div>
                        </div>
                        <div className="bg-orange-50/60 p-3 rounded-lg">
                          <div className="text-xs text-orange-600 font-medium">Error Rate</div>
                          <div className="text-lg font-bold text-orange-900">
                            {(func.errorRate * 100).toFixed(2)}%
                          </div>
                        </div>
                      </div>

                      {/* Scaling Configuration */}
                      <div className="space-y-2">
                        <div className="text-sm font-medium text-gray-700">Auto-Scaling Config</div>
                        <div className="bg-gray-50/60 p-3 rounded-lg">
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <div>
                              <span className="text-gray-600">Min Instances:</span>
                              <span className="ml-1 font-medium">{func.scalingConfig.minInstances}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Max Instances:</span>
                              <span className="ml-1 font-medium">{func.scalingConfig.maxInstances}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Target Concurrency:</span>
                              <span className="ml-1 font-medium">{func.scalingConfig.targetConcurrency}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Cold Starts:</span>
                              <span className="ml-1 font-medium">{func.coldStarts}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex gap-2">
                        <Button
                          onClick={() => deployFunction(func.id)}
                          variant="outline"
                          size="sm"
                          className="flex-1"
                          disabled={func.status === 'deploying'}
                        >
                          {func.status === 'deploying' ? (
                            <RefreshCw className="w-4 h-4 mr-1 animate-spin" />
                          ) : (
                            <Package className="w-4 h-4 mr-1" />
                          )}
                          Deploy
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1"
                        >
                          <Settings className="w-4 h-4 mr-1" />
                          Config
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </TabsContent>

        {/* Edge Locations */}
        <TabsContent value="edge" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {edgeLocations.map((location) => (
              <motion.div
                key={location.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-gradient-to-br from-emerald-50/80 to-teal-50/80 backdrop-blur-sm border-emerald-200/30">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Globe className="w-4 h-4 text-emerald-600" />
                        <Badge className={getStatusColor(location.status)}>
                          {location.status.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600">{location.country}</div>
                    </div>
                    <CardTitle className="text-lg">{location.region}</CardTitle>
                    <p className="text-sm text-gray-600">{location.city}</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Performance Metrics */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-white/60 p-3 rounded-lg">
                        <div className="text-xs text-gray-600 font-medium">Latency</div>
                        <div className="text-lg font-bold text-gray-900">{location.latency}ms</div>
                      </div>
                      <div className="bg-white/60 p-3 rounded-lg">
                        <div className="text-xs text-gray-600 font-medium">Requests</div>
                        <div className="text-lg font-bold text-gray-900">
                          {location.requests.toLocaleString()}
                        </div>
                      </div>
                    </div>

                    {/* Cache Hit Rate */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-700">Cache Hit Rate</span>
                        <span className="text-gray-600">{location.cacheHitRate}%</span>
                      </div>
                      <Progress value={location.cacheHitRate} className="h-2" />
                    </div>

                    {/* Services */}
                    <div className="space-y-2">
                      <div className="text-sm font-medium text-gray-700">Available Services</div>
                      <div className="flex flex-wrap gap-1">
                        {location.services.map((service, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {service}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {/* AI Workloads */}
        <TabsContent value="ai-workloads" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {aiWorkloads.map((workload) => (
              <motion.div
                key={workload.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-gradient-to-br from-purple-50/80 to-pink-50/80 backdrop-blur-sm border-purple-200/30">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Brain className="w-4 h-4 text-purple-600" />
                        <Badge 
                          variant="outline" 
                          className="bg-purple-100 text-purple-800 border-purple-200"
                        >
                          {workload.type.replace('_', ' ').toUpperCase()}
                        </Badge>
                      </div>
                      {workload.gpuRequired && (
                        <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">
                          GPU Required
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-lg capitalize">
                      {workload.type.replace(/_/g, ' ')}
                    </CardTitle>
                    <p className="text-sm text-gray-600">{workload.model}</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Performance Requirements */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-white/60 p-3 rounded-lg">
                        <div className="text-xs text-gray-600 font-medium">Latency Req.</div>
                        <div className="text-lg font-bold text-gray-900">
                          {workload.latencyRequirement}ms
                        </div>
                      </div>
                      <div className="bg-white/60 p-3 rounded-lg">
                        <div className="text-xs text-gray-600 font-medium">Accuracy Target</div>
                        <div className="text-lg font-bold text-gray-900">
                          {workload.accuracyTarget}%
                        </div>
                      </div>
                      <div className="bg-white/60 p-3 rounded-lg">
                        <div className="text-xs text-gray-600 font-medium">Compute Units</div>
                        <div className="text-lg font-bold text-gray-900">
                          {workload.computeUnits}
                        </div>
                      </div>
                      <div className="bg-white/60 p-3 rounded-lg">
                        <div className="text-xs text-gray-600 font-medium">Scaling Pattern</div>
                        <div className="text-sm font-bold text-gray-900 capitalize">
                          {workload.scalingPattern}
                        </div>
                      </div>
                    </div>

                    {/* Data Flow */}
                    <div className="space-y-2">
                      <div className="text-sm font-medium text-gray-700">Data Flow</div>
                      <div className="bg-gray-50/60 p-3 rounded-lg">
                        <div className="flex items-center justify-between text-xs">
                          <span>Input Size: {workload.inputSize.toLocaleString()} bytes</span>
                          <ArrowUp className="w-3 h-3 text-gray-400" />
                        </div>
                        <div className="flex items-center justify-center my-2">
                          <div className="w-full h-1 bg-purple-200 rounded"></div>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <ArrowDown className="w-3 h-3 text-gray-400" />
                          <span>Output Size: {workload.outputSize.toLocaleString()} bytes</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {/* Real-time Monitoring */}
        <TabsContent value="monitoring" className="space-y-4">
          <Card className="bg-gradient-to-br from-gray-50/80 to-slate-50/80 backdrop-blur-sm border-gray-200/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-900">
                <Monitor className="w-5 h-5" />
                Real-time Infrastructure Monitoring
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Monitoring Controls */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">Monitoring Interval</label>
                    <select
                      value={monitoringInterval}
                      onChange={(e) => setMonitoringInterval(parseInt(e.target.value))}
                      className="w-full p-2 text-sm border border-gray-200 rounded-lg bg-white"
                    >
                      <option value={1000}>1 second</option>
                      <option value={5000}>5 seconds</option>
                      <option value={10000}>10 seconds</option>
                      <option value={30000}>30 seconds</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">Response Time Alert (ms)</label>
                    <input
                      type="number"
                      value={alertThresholds.responseTime}
                      onChange={(e) => setAlertThresholds(prev => ({
                        ...prev,
                        responseTime: parseInt(e.target.value)
                      }))}
                      className="w-full p-2 text-sm border border-gray-200 rounded-lg"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">CPU Alert (%)</label>
                    <input
                      type="number"
                      value={alertThresholds.cpuUsage}
                      onChange={(e) => setAlertThresholds(prev => ({
                        ...prev,
                        cpuUsage: parseInt(e.target.value)
                      }))}
                      className="w-full p-2 text-sm border border-gray-200 rounded-lg"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">Memory Alert (%)</label>
                    <input
                      type="number"
                      value={alertThresholds.memoryUsage}
                      onChange={(e) => setAlertThresholds(prev => ({
                        ...prev,
                        memoryUsage: parseInt(e.target.value)
                      }))}
                      className="w-full p-2 text-sm border border-gray-200 rounded-lg"
                    />
                  </div>
                </div>

                {/* Real-time Metrics Chart */}
                <div className="bg-white/60 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-4">Live Performance Metrics</h4>
                  <div className="space-y-4">
                    {realTimeMetrics.slice(0, 10).map((metric, index) => (
                      <motion.div
                        key={metric.timestamp}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="grid grid-cols-4 gap-4 p-3 bg-gray-50/60 rounded-lg"
                      >
                        <div className="text-center">
                          <div className="text-xs text-gray-600">Response Time</div>
                          <div className={`text-lg font-bold ${metric.responseTime > alertThresholds.responseTime ? 'text-red-600' : 'text-green-600'}`}>
                            {metric.responseTime}ms
                          </div>
                        </div>
                        <div className="text-center">
                          <div className="text-xs text-gray-600">CPU Usage</div>
                          <div className={`text-lg font-bold ${metric.cpuUsage > alertThresholds.cpuUsage ? 'text-red-600' : 'text-blue-600'}`}>
                            {metric.cpuUsage}%
                          </div>
                        </div>
                        <div className="text-center">
                          <div className="text-xs text-gray-600">Memory Usage</div>
                          <div className={`text-lg font-bold ${metric.memoryUsage > alertThresholds.memoryUsage ? 'text-red-600' : 'text-purple-600'}`}>
                            {metric.memoryUsage}%
                          </div>
                        </div>
                        <div className="text-center">
                          <div className="text-xs text-gray-600">Error Rate</div>
                          <div className={`text-lg font-bold ${metric.errorRate > alertThresholds.errorRate ? 'text-red-600' : 'text-green-600'}`}>
                            {metric.errorRate.toFixed(2)}%
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Cloud Providers */}
        <TabsContent value="providers" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cloudProviders.map((provider) => (
              <motion.div
                key={provider.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-gradient-to-br from-cyan-50/80 to-blue-50/80 backdrop-blur-sm border-cyan-200/30">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{provider.name}</CardTitle>
                      <Badge 
                        variant={activeProvider === provider.name.toLowerCase() ? 'default' : 'outline'}
                        className={activeProvider === provider.name.toLowerCase() ? 'bg-cyan-600 text-white' : ''}
                      >
                        {activeProvider === provider.name.toLowerCase() ? 'Active' : 'Available'}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Services */}
                    <div className="space-y-3">
                      {Object.entries(provider.services).map(([category, services]) => (
                        <div key={category}>
                          <div className="text-sm font-medium text-gray-700 capitalize">{category}</div>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {services.map((service, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {service}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Pricing */}
                    <div className="bg-white/60 p-3 rounded-lg">
                      <div className="text-sm font-medium text-gray-700 mb-2">Pricing (USD)</div>
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span>Compute per hour:</span>
                          <span>${provider.pricing.compute.toFixed(6)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Storage per GB/month:</span>
                          <span>${provider.pricing.storage.toFixed(3)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Bandwidth per GB:</span>
                          <span>${provider.pricing.bandwidth.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Features */}
                    <div className="space-y-2">
                      <div className="text-sm font-medium text-gray-700">Key Features</div>
                      <div className="space-y-1">
                        {provider.features.map((feature, index) => (
                          <div key={index} className="text-xs text-gray-600 flex items-center gap-1">
                            <CheckCircle className="w-3 h-3 text-green-500" />
                            {feature}
                          </div>
                        ))}
                      </div>
                    </div>

                    <Button
                      onClick={() => setActiveProvider(provider.name.toLowerCase())}
                      variant={activeProvider === provider.name.toLowerCase() ? 'default' : 'outline'}
                      className="w-full"
                      disabled={activeProvider === provider.name.toLowerCase()}
                    >
                      {activeProvider === provider.name.toLowerCase() ? 'Currently Active' : 'Switch Provider'}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
