import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import {
  Brain,
  Zap,
  Target,
  Eye,
  Timer,
  TrendingUp,
  Activity,
  Lightbulb,
  Sparkles,
  RotateCw,
  Play,
  Pause,
  Square,
  SkipForward,
  Award,
  Star,
  CheckCircle,
  AlertTriangle,
  Heart,
  Headphones,
  Volume2,
} from "lucide-react";

interface CognitiveTask {
  id: string;
  name: string;
  type: "memory" | "attention" | "spatial" | "emotional" | "multimodal";
  difficulty: number;
  targetRegions: string[];
  neurotransmitters: string[];
  estimatedDuration: number;
  description: string;
}

interface PerformanceMetrics {
  accuracy: number;
  reactionTime: number;
  cognitiveLoad: number;
  focusLevel: number;
  stressLevel: number;
  emotionalState: string;
  neuralActivity: Record<string, number>;
}

interface AdaptiveSettings {
  difficulty: number;
  stimulusIntensity: number;
  feedbackFrequency: number;
  adaptationRate: number;
  targetAccuracy: number;
  maxCognitiveLoad: number;
}

interface CognitiveTrainingEngineProps {
  userId?: string;
  onMetricsUpdate?: (metrics: PerformanceMetrics) => void;
  onTaskComplete?: (taskId: string, performance: PerformanceMetrics) => void;
}

export default function CognitiveTrainingEngine({
  userId = "demo-user",
  onMetricsUpdate,
  onTaskComplete,
}: CognitiveTrainingEngineProps) {
  const { toast } = useToast();
  const [currentTask, setCurrentTask] = useState<CognitiveTask | null>(null);
  const [isTraining, setIsTraining] = useState(false);
  const [sessionTime, setSessionTime] = useState(0);
  const [taskProgress, setTaskProgress] = useState(0);
  const [currentMetrics, setCurrentMetrics] = useState<PerformanceMetrics>({
    accuracy: 0,
    reactionTime: 0,
    cognitiveLoad: 0.3,
    focusLevel: 0.8,
    stressLevel: 0.2,
    emotionalState: "neutral",
    neuralActivity: {
      prefrontal: 0.6,
      hippocampus: 0.4,
      amygdala: 0.2,
      motor: 0.3,
      visual: 0.5,
    },
  });

  const [adaptiveSettings, setAdaptiveSettings] = useState<AdaptiveSettings>({
    difficulty: 0.5,
    stimulusIntensity: 0.7,
    feedbackFrequency: 0.8,
    adaptationRate: 0.3,
    targetAccuracy: 0.75,
    maxCognitiveLoad: 0.8,
  });

  const [availableTasks] = useState<CognitiveTask[]>([
    {
      id: "adaptive-nback",
      name: "Adaptive N-Back Memory",
      type: "memory",
      difficulty: 0.6,
      targetRegions: ["prefrontal", "hippocampus"],
      neurotransmitters: ["dopamine", "acetylcholine"],
      estimatedDuration: 300,
      description:
        "Advanced working memory training with real-time difficulty adaptation",
    },
    {
      id: "emotional-stroop",
      name: "Emotional Stroop Task",
      type: "emotional",
      difficulty: 0.4,
      targetRegions: ["amygdala", "prefrontal"],
      neurotransmitters: ["serotonin", "gaba"],
      estimatedDuration: 240,
      description: "Emotional regulation training with color-word interference",
    },
    {
      id: "spatial-navigation",
      name: "Virtual Spatial Navigation",
      type: "spatial",
      difficulty: 0.7,
      targetRegions: ["hippocampus", "visual"],
      neurotransmitters: ["acetylcholine", "glutamate"],
      estimatedDuration: 420,
      description: "Navigate through 3D environments to enhance spatial memory",
    },
    {
      id: "attention-network",
      name: "Attention Network Training",
      type: "attention",
      difficulty: 0.5,
      targetRegions: ["prefrontal", "visual"],
      neurotransmitters: ["dopamine", "acetylcholine"],
      estimatedDuration: 360,
      description: "Multi-component attention training with network analysis",
    },
    {
      id: "crossmodal-binding",
      name: "Cross-Modal Memory Binding",
      type: "multimodal",
      difficulty: 0.8,
      targetRegions: ["hippocampus", "prefrontal", "visual"],
      neurotransmitters: ["glutamate", "acetylcholine"],
      estimatedDuration: 480,
      description: "Advanced multi-sensory memory integration training",
    },
  ]);

  const timerRef = useRef<NodeJS.Timeout>();
  const metricsRef = useRef<NodeJS.Timeout>();

  // AI Adaptation Engine
  const adaptDifficulty = useCallback(
    (performance: PerformanceMetrics) => {
      const { accuracy, cognitiveLoad, reactionTime } = performance;
      const { targetAccuracy, maxCognitiveLoad, adaptationRate } =
        adaptiveSettings;

      let difficultyAdjustment = 0;

      // Accuracy-based adaptation
      if (accuracy > targetAccuracy + 0.1) {
        difficultyAdjustment += adaptationRate * 0.1;
      } else if (accuracy < targetAccuracy - 0.1) {
        difficultyAdjustment -= adaptationRate * 0.1;
      }

      // Cognitive load adaptation
      if (cognitiveLoad > maxCognitiveLoad) {
        difficultyAdjustment -= adaptationRate * 0.05;
      }

      // Reaction time adaptation
      if (reactionTime > 1000) {
        difficultyAdjustment -= adaptationRate * 0.03;
      } else if (reactionTime < 300) {
        difficultyAdjustment += adaptationRate * 0.03;
      }

      setAdaptiveSettings((prev) => ({
        ...prev,
        difficulty: Math.max(
          0.1,
          Math.min(1.0, prev.difficulty + difficultyAdjustment),
        ),
      }));
    },
    [adaptiveSettings],
  );

  // Simulate real-time metrics
  useEffect(() => {
    if (isTraining && currentTask) {
      metricsRef.current = setInterval(() => {
        const newMetrics: PerformanceMetrics = {
          accuracy: Math.max(
            0,
            Math.min(1, currentMetrics.accuracy + (Math.random() - 0.5) * 0.1),
          ),
          reactionTime: Math.max(
            200,
            currentMetrics.reactionTime + (Math.random() - 0.5) * 100,
          ),
          cognitiveLoad: Math.max(
            0,
            Math.min(
              1,
              0.3 +
                Math.sin(Date.now() / 10000) * 0.3 +
                adaptiveSettings.difficulty * 0.4,
            ),
          ),
          focusLevel: Math.max(
            0,
            Math.min(1, 0.8 + Math.sin(Date.now() / 5000) * 0.2),
          ),
          stressLevel: Math.max(
            0,
            Math.min(
              1,
              0.1 + adaptiveSettings.difficulty * 0.3 + Math.random() * 0.1,
            ),
          ),
          emotionalState: getEmotionalState(),
          neuralActivity: generateNeuralActivity(currentTask),
        };

        setCurrentMetrics(newMetrics);
        adaptDifficulty(newMetrics);

        if (onMetricsUpdate) {
          onMetricsUpdate(newMetrics);
        }
      }, 1000);
    }

    return () => {
      if (metricsRef.current) {
        clearInterval(metricsRef.current);
      }
    };
  }, [isTraining, currentTask, adaptDifficulty, onMetricsUpdate]);

  // Session timer
  useEffect(() => {
    if (isTraining) {
      timerRef.current = setInterval(() => {
        setSessionTime((prev) => {
          const newTime = prev + 1;
          if (currentTask && newTime >= currentTask.estimatedDuration) {
            completeTask();
          }
          return newTime;
        });
        setTaskProgress((prev) =>
          Math.min(100, prev + 100 / (currentTask?.estimatedDuration || 300)),
        );
      }, 1000);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isTraining, currentTask]);

  const getEmotionalState = (): string => {
    const { stressLevel, focusLevel } = currentMetrics;
    if (stressLevel > 0.7) return "stressed";
    if (focusLevel > 0.8) return "focused";
    if (stressLevel < 0.3 && focusLevel > 0.6) return "calm";
    return "neutral";
  };

  const generateNeuralActivity = (
    task: CognitiveTask,
  ): Record<string, number> => {
    const baseActivity = {
      prefrontal: 0.3,
      hippocampus: 0.2,
      amygdala: 0.1,
      motor: 0.1,
      visual: 0.2,
    };

    task.targetRegions.forEach((region) => {
      baseActivity[region as keyof typeof baseActivity] = Math.min(
        1,
        baseActivity[region as keyof typeof baseActivity] +
          0.3 +
          Math.random() * 0.3 +
          adaptiveSettings.difficulty * 0.2,
      );
    });

    return baseActivity;
  };

  const startTask = (task: CognitiveTask) => {
    setCurrentTask(task);
    setIsTraining(true);
    setSessionTime(0);
    setTaskProgress(0);
    setCurrentMetrics((prev) => ({
      ...prev,
      accuracy: 0,
      reactionTime: 500,
    }));

    toast({
      title: "Training Started",
      description: `Beginning ${task.name} - Duration: ${Math.round(task.estimatedDuration / 60)} minutes`,
    });
  };

  const pauseTask = () => {
    setIsTraining(false);
    toast({
      title: "Training Paused",
      description: "Take a break - your progress is saved",
    });
  };

  const resumeTask = () => {
    setIsTraining(true);
    toast({
      title: "Training Resumed",
      description: "Welcome back - let's continue enhancing your cognition",
    });
  };

  const stopTask = () => {
    setIsTraining(false);
    setCurrentTask(null);
    setSessionTime(0);
    setTaskProgress(0);

    toast({
      title: "Training Stopped",
      description: "Session ended - your progress has been saved",
    });
  };

  const completeTask = () => {
    if (currentTask && onTaskComplete) {
      onTaskComplete(currentTask.id, currentMetrics);
    }

    setIsTraining(false);
    setTaskProgress(100);

    toast({
      title: "Task Completed!",
      description: `Excellent work! Accuracy: ${Math.round(currentMetrics.accuracy * 100)}%`,
    });
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const getNeurotransmitterColor = (neurotransmitter: string): string => {
    const colors = {
      dopamine: "bg-pink-200 text-pink-800",
      serotonin: "bg-blue-200 text-blue-800",
      gaba: "bg-green-200 text-green-800",
      glutamate: "bg-orange-200 text-orange-800",
      acetylcholine: "bg-purple-200 text-purple-800",
    };
    return (
      colors[neurotransmitter as keyof typeof colors] ||
      "bg-gray-200 text-gray-800"
    );
  };

  return (
    <div className="space-y-6">
      {/* Current Training Session */}
      {currentTask && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="cognitive-enhancement-card p-6 rounded-2xl"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-2xl font-bold neural-text">
                {currentTask.name}
              </h3>
              <p className="text-gray-600 mt-1">{currentTask.description}</p>
            </div>
            <div className="flex items-center gap-2">
              {!isTraining ? (
                <>
                  <Button onClick={resumeTask} className="neural-button">
                    <Play className="h-4 w-4 mr-2" />
                    Resume
                  </Button>
                  <Button
                    onClick={stopTask}
                    variant="outline"
                    className="neural-button"
                  >
                    <Square className="h-4 w-4 mr-2" />
                    Stop
                  </Button>
                </>
              ) : (
                <Button onClick={pauseTask} className="neural-button">
                  <Pause className="h-4 w-4 mr-2" />
                  Pause
                </Button>
              )}
            </div>
          </div>

          {/* Progress and Timer */}
          <div className="grid md:grid-cols-2 gap-6 mb-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Session Progress</span>
                <span>
                  {formatTime(sessionTime)} /{" "}
                  {formatTime(currentTask.estimatedDuration)}
                </span>
              </div>
              <Progress value={taskProgress} className="h-3 cognitive-load" />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Adaptive Difficulty</span>
                <span>{Math.round(adaptiveSettings.difficulty * 100)}%</span>
              </div>
              <Progress
                value={adaptiveSettings.difficulty * 100}
                className="h-3"
              />
            </div>
          </div>

          {/* Real-time Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
            <div className="text-center p-3 bg-white/20 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {Math.round(currentMetrics.accuracy * 100)}%
              </div>
              <div className="text-xs text-gray-600">Accuracy</div>
            </div>

            <div className="text-center p-3 bg-white/20 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                {Math.round(currentMetrics.reactionTime)}ms
              </div>
              <div className="text-xs text-gray-600">Reaction Time</div>
            </div>

            <div className="text-center p-3 bg-white/20 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">
                {Math.round(currentMetrics.cognitiveLoad * 100)}%
              </div>
              <div className="text-xs text-gray-600">Cognitive Load</div>
            </div>

            <div className="text-center p-3 bg-white/20 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                {Math.round(currentMetrics.focusLevel * 100)}%
              </div>
              <div className="text-xs text-gray-600">Focus Level</div>
            </div>

            <div className="text-center p-3 bg-white/20 rounded-lg">
              <div
                className={`text-sm font-medium capitalize cognitive-state-indicator ${currentMetrics.emotionalState}`}
              >
                {currentMetrics.emotionalState}
              </div>
              <div className="text-xs text-gray-600">Emotional State</div>
            </div>
          </div>

          {/* Neural Activity Visualization */}
          <div className="space-y-3">
            <h4 className="text-lg font-semibold flex items-center gap-2">
              <Brain className="h-5 w-5" />
              Real-time Neural Activity
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
              {Object.entries(currentMetrics?.neuralActivity || {}).map(
                ([region, activity]) => (
                  <div key={region} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="capitalize">{region}</span>
                      <span>{Math.round(activity * 100)}%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <motion.div
                        className={`h-full neural-pulse ${
                          activity > 0.7
                            ? "bg-red-400"
                            : activity > 0.5
                              ? "bg-yellow-400"
                              : activity > 0.3
                                ? "bg-green-400"
                                : "bg-blue-400"
                        }`}
                        style={{ width: `${activity * 100}%` }}
                        animate={{ opacity: [0.6, 1, 0.6] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      />
                    </div>
                  </div>
                ),
              )}
            </div>
          </div>
        </motion.div>
      )}

      {/* Available Training Tasks */}
      {!currentTask && (
        <div className="space-y-6">
          <div className="text-center">
            <h2 className="text-3xl font-bold neural-text mb-4">
              Advanced Cognitive Training
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              AI-powered adaptive training modules that adjust in real-time to
              optimize your cognitive enhancement. Each task targets specific
              brain regions and neurotransmitter systems.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {(availableTasks || []).map((task, index) => (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card
                  className="cognitive-enhancement-card h-full hover:shadow-lg transition-all duration-300 cursor-pointer"
                  onClick={() => startTask(task)}
                >
                  <CardHeader>
                    <div className="flex items-center gap-3 mb-2">
                      <div
                        className={`w-12 h-12 rounded-lg flex items-center justify-center
                        ${
                          task.type === "memory"
                            ? "bg-blue-100 text-blue-600"
                            : task.type === "attention"
                              ? "bg-green-100 text-green-600"
                              : task.type === "spatial"
                                ? "bg-purple-100 text-purple-600"
                                : task.type === "emotional"
                                  ? "bg-pink-100 text-pink-600"
                                  : "bg-orange-100 text-orange-600"
                        }`}
                      >
                        {task.type === "memory" && (
                          <Brain className="h-6 w-6" />
                        )}
                        {task.type === "attention" && (
                          <Eye className="h-6 w-6" />
                        )}
                        {task.type === "spatial" && (
                          <Target className="h-6 w-6" />
                        )}
                        {task.type === "emotional" && (
                          <Heart className="h-6 w-6" />
                        )}
                        {task.type === "multimodal" && (
                          <Sparkles className="h-6 w-6" />
                        )}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{task.name}</CardTitle>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="secondary" className="text-xs">
                            {task.type.toUpperCase()}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {Math.round(task.estimatedDuration / 60)} min
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <CardDescription className="text-sm">
                      {task.description}
                    </CardDescription>
                  </CardHeader>

                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Difficulty Level</span>
                          <span>{Math.round(task.difficulty * 100)}%</span>
                        </div>
                        <Progress
                          value={task.difficulty * 100}
                          className="h-2"
                        />
                      </div>

                      <div>
                        <h5 className="text-sm font-medium mb-2">
                          Target Brain Regions
                        </h5>
                        <div className="flex flex-wrap gap-1">
                          {(task.targetRegions || []).map((region) => (
                            <Badge
                              key={region}
                              variant="outline"
                              className="text-xs capitalize"
                            >
                              {region}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h5 className="text-sm font-medium mb-2">
                          Neurotransmitter Systems
                        </h5>
                        <div className="flex flex-wrap gap-1">
                          {(task.neurotransmitters || []).map((nt) => (
                            <Badge
                              key={nt}
                              className={`text-xs capitalize ${getNeurotransmitterColor(nt)}`}
                            >
                              {nt}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Adaptive Settings Panel */}
      <Card className="cognitive-enhancement-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RotateCw className="h-5 w-5" />
            AI Adaptation Settings
          </CardTitle>
          <CardDescription>
            Configure how the AI adapts training difficulty and feedback in
            real-time
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Target Accuracy:{" "}
                  {Math.round(adaptiveSettings.targetAccuracy * 100)}%
                </label>
                <Slider
                  value={[adaptiveSettings.targetAccuracy * 100]}
                  onValueChange={([value]) =>
                    setAdaptiveSettings((prev) => ({
                      ...prev,
                      targetAccuracy: value / 100,
                    }))
                  }
                  max={100}
                  step={5}
                  className="w-full"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">
                  Adaptation Rate:{" "}
                  {Math.round(adaptiveSettings.adaptationRate * 100)}%
                </label>
                <Slider
                  value={[adaptiveSettings.adaptationRate * 100]}
                  onValueChange={([value]) =>
                    setAdaptiveSettings((prev) => ({
                      ...prev,
                      adaptationRate: value / 100,
                    }))
                  }
                  max={100}
                  step={5}
                  className="w-full"
                />
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Max Cognitive Load:{" "}
                  {Math.round(adaptiveSettings.maxCognitiveLoad * 100)}%
                </label>
                <Slider
                  value={[adaptiveSettings.maxCognitiveLoad * 100]}
                  onValueChange={([value]) =>
                    setAdaptiveSettings((prev) => ({
                      ...prev,
                      maxCognitiveLoad: value / 100,
                    }))
                  }
                  max={100}
                  step={5}
                  className="w-full"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">
                  Stimulus Intensity:{" "}
                  {Math.round(adaptiveSettings.stimulusIntensity * 100)}%
                </label>
                <Slider
                  value={[adaptiveSettings.stimulusIntensity * 100]}
                  onValueChange={([value]) =>
                    setAdaptiveSettings((prev) => ({
                      ...prev,
                      stimulusIntensity: value / 100,
                    }))
                  }
                  max={100}
                  step={5}
                  className="w-full"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
