import { useRef, useEffect, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Sphere, Text, Float, Environment } from '@react-three/drei';
import { motion } from 'framer-motion';
import * as THREE from 'three';

interface NodeProps {
  position: [number, number, number];
  color: string;
  label: string;
  scale?: number;
}

function AnimatedNode({ position, color, label, scale = 1 }: NodeProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime) * 0.2;
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 1.2) * 0.2;
      meshRef.current.scale.setScalar(hovered ? scale * 1.2 : scale);
    }
  });

  return (
    <Float speed={2} rotationIntensity={0.1} floatIntensity={0.2}>
      <group position={position}>
        <Sphere
          ref={meshRef}
          args={[0.5, 32, 32]}
          onPointerEnter={() => setHovered(true)}
          onPointerLeave={() => setHovered(false)}
        >
          <meshStandardMaterial
            color={color}
            emissive={color}
            emissiveIntensity={hovered ? 0.3 : 0.1}
            metalness={0.8}
            roughness={0.2}
          />
        </Sphere>
        <Text
          position={[0, -1, 0]}
          fontSize={0.3}
          color="white"
          anchorX="center"
          anchorY="middle"
          font="/fonts/inter-bold.woff"
        >
          {label}
        </Text>
      </group>
    </Float>
  );
}

function ConnectionLine({ start, end }: { start: [number, number, number]; end: [number, number, number] }) {
  const points = [new THREE.Vector3(...start), new THREE.Vector3(...end)];
  const lineGeometry = new THREE.BufferGeometry().setFromPoints(points);

  return (
    <line geometry={lineGeometry}>
      <lineBasicMaterial color="#4f46e5" linewidth={2} />
    </line>
  );
}

function TechStackVisualization() {
  const nodes = [
    { position: [0, 0, 0] as [number, number, number], color: "#3b82f6", label: "React" },
    { position: [-3, 2, 0] as [number, number, number], color: "#10b981", label: "Vue" },
    { position: [3, 2, 0] as [number, number, number], color: "#f59e0b", label: "Svelte" },
    { position: [-2, -2, 2] as [number, number, number], color: "#8b5cf6", label: "Redux" },
    { position: [2, -2, 2] as [number, number, number], color: "#06b6d4", label: "Zustand" },
    { position: [0, 3, -2] as [number, number, number], color: "#ef4444", label: "TypeScript" },
  ];

  const connections = [
    { start: [0, 0, 0] as [number, number, number], end: [-3, 2, 0] as [number, number, number] },
    { start: [0, 0, 0] as [number, number, number], end: [3, 2, 0] as [number, number, number] },
    { start: [0, 0, 0] as [number, number, number], end: [-2, -2, 2] as [number, number, number] },
    { start: [0, 0, 0] as [number, number, number], end: [2, -2, 2] as [number, number, number] },
    { start: [0, 0, 0] as [number, number, number], end: [0, 3, -2] as [number, number, number] },
  ];

  return (
    <>
      <Environment preset="studio" />
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#3b82f6" />
      
      {connections.map((connection, index) => (
        <ConnectionLine key={index} start={connection.start} end={connection.end} />
      ))}
      
      {nodes.map((node, index) => (
        <AnimatedNode
          key={index}
          position={node.position}
          color={node.color}
          label={node.label}
          scale={node.label === "React" ? 1.2 : 1}
        />
      ))}
      
      <OrbitControls
        enablePan={true}
        enableZoom={true}
        enableRotate={true}
        autoRotate={true}
        autoRotateSpeed={0.5}
      />
    </>
  );
}

interface ThreeSceneProps {
  className?: string;
}

export default function ThreeScene({ className = "" }: ThreeSceneProps) {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <motion.div
      className={`relative ${className}`}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.8, delay: 0.2 }}
    >
      <div className="w-full h-[400px] bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 rounded-lg overflow-hidden border border-slate-700">
        {isLoaded ? (
          <Canvas
            camera={{
              position: [0, 0, 8],
              fov: 60,
            }}
            style={{ background: 'transparent' }}
          >
            <TechStackVisualization />
          </Canvas>
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <div className="text-center text-white">
              <div className="animate-spin w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full mx-auto mb-4"></div>
              <p>Loading 3D Visualization...</p>
            </div>
          </div>
        )}
      </div>
      
      <div className="absolute bottom-4 left-4 text-white text-sm bg-black/50 px-3 py-1 rounded-full backdrop-blur-sm">
        🖱️ Click and drag to rotate • Scroll to zoom
      </div>
    </motion.div>
  );
}
