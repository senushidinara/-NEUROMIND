import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import {
  Camera,
  Heart,
  Brain,
  Eye,
  Smile,
  Frown,
  Meh,
  AlertCircle,
  Activity,
  Zap,
  Thermometer,
  Volume2,
  Mic,
  Play,
  Pause,
  Settings,
  TrendingUp,
  BarChart3,
  Lightbulb,
} from "lucide-react";

interface EmotionData {
  happiness: number;
  sadness: number;
  anger: number;
  fear: number;
  surprise: number;
  disgust: number;
  neutral: number;
  dominant: string;
  confidence: number;
}

interface BiofeedbackData {
  heartRate: number;
  hrv: number; // Heart Rate Variability
  skinConductance: number;
  facialTension: number;
  voiceStress: number;
  cognitiveLoad: number;
}

interface CalibrationData {
  baseline: EmotionData;
  personalityFactors: {
    extroversion: number;
    neuroticism: number;
    openness: number;
    conscientiousness: number;
    agreeableness: number;
  };
  stressThreshold: number;
  optimalArousal: number;
}

interface EmotionBiofeedbackProps {
  onEmotionChange?: (emotion: EmotionData) => void;
  onBiofeedbackChange?: (biofeedback: BiofeedbackData) => void;
  onAdaptationSuggestion?: (suggestion: string) => void;
}

export default function EmotionBiofeedback({
  onEmotionChange,
  onBiofeedbackChange,
  onAdaptationSuggestion,
}: EmotionBiofeedbackProps) {
  const { toast } = useToast();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);

  const [isActive, setIsActive] = useState(false);
  const [isCalibrated, setIsCalibrated] = useState(false);
  const [calibrationProgress, setCalibrationProgress] = useState(0);
  const [cameraEnabled, setCameraEnabled] = useState(false);
  const [microphoneEnabled, setMicrophoneEnabled] = useState(false);

  const [currentEmotion, setCurrentEmotion] = useState<EmotionData>({
    happiness: 0.3,
    sadness: 0.1,
    anger: 0.05,
    fear: 0.1,
    surprise: 0.1,
    disgust: 0.05,
    neutral: 0.3,
    dominant: "neutral",
    confidence: 0.7,
  });

  const [biofeedback, setBiofeedback] = useState<BiofeedbackData>({
    heartRate: 72,
    hrv: 45,
    skinConductance: 0.3,
    facialTension: 0.2,
    voiceStress: 0.15,
    cognitiveLoad: 0.4,
  });

  const [calibration, setCalibration] = useState<CalibrationData>({
    baseline: currentEmotion,
    personalityFactors: {
      extroversion: 0.5,
      neuroticism: 0.3,
      openness: 0.7,
      conscientiousness: 0.6,
      agreeableness: 0.6,
    },
    stressThreshold: 0.7,
    optimalArousal: 0.6,
  });

  const [adaptationSuggestions, setAdaptationSuggestions] = useState<string[]>(
    [],
  );

  // Emotion color mapping
  const emotionColors = {
    happiness: "bg-yellow-200 text-yellow-800",
    sadness: "bg-blue-200 text-blue-800",
    anger: "bg-red-200 text-red-800",
    fear: "bg-purple-200 text-purple-800",
    surprise: "bg-orange-200 text-orange-800",
    disgust: "bg-green-200 text-green-800",
    neutral: "bg-gray-200 text-gray-800",
  };

  // Initialize camera stream
  const initializeCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: false,
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setCameraEnabled(true);

        toast({
          title: "Camera Activated",
          description: "Facial emotion recognition is now active",
        });
      }
    } catch (error) {
      console.error("Error accessing camera:", error);
      toast({
        title: "Camera Access Denied",
        description: "Please enable camera access for emotion recognition",
        variant: "destructive",
      });
    }
  }, [toast]);

  // Initialize microphone for voice stress analysis
  const initializeMicrophone = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: false,
        audio: true,
      });

      audioContextRef.current = new (window.AudioContext ||
        (window as any).webkitAudioContext)();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      analyserRef.current = audioContextRef.current.createAnalyser();

      analyserRef.current.fftSize = 2048;
      source.connect(analyserRef.current);

      setMicrophoneEnabled(true);

      toast({
        title: "Microphone Activated",
        description: "Voice stress analysis is now active",
      });
    } catch (error) {
      console.error("Error accessing microphone:", error);
      toast({
        title: "Microphone Access Denied",
        description: "Please enable microphone access for voice analysis",
        variant: "destructive",
      });
    }
  }, [toast]);

  // Simulate emotion detection (in real implementation, this would use face-api.js or similar)
  const simulateEmotionDetection = useCallback(() => {
    if (!cameraEnabled) return;

    // Simulate realistic emotion fluctuations
    const time = Date.now() / 1000;
    const baseHappiness = 0.3 + Math.sin(time * 0.1) * 0.2;
    const baseStress = Math.max(0, Math.sin(time * 0.05) * 0.3);

    const newEmotion: EmotionData = {
      happiness: Math.max(
        0,
        Math.min(1, baseHappiness + (Math.random() - 0.5) * 0.1),
      ),
      sadness: Math.max(
        0,
        Math.min(1, 0.1 + baseStress * 0.3 + (Math.random() - 0.5) * 0.1),
      ),
      anger: Math.max(
        0,
        Math.min(1, 0.05 + baseStress * 0.2 + (Math.random() - 0.5) * 0.05),
      ),
      fear: Math.max(
        0,
        Math.min(1, 0.1 + baseStress * 0.4 + (Math.random() - 0.5) * 0.1),
      ),
      surprise: Math.max(0, Math.min(1, 0.1 + (Math.random() - 0.5) * 0.1)),
      disgust: Math.max(0, Math.min(1, 0.05 + (Math.random() - 0.5) * 0.05)),
      neutral: 0,
      dominant: "",
      confidence: 0.7 + Math.random() * 0.3,
    };

    // Calculate neutral as remainder
    const totalOthers = Object.values(newEmotion)
      .slice(0, -3)
      .reduce((sum, val) => sum + val, 0);
    newEmotion.neutral = Math.max(0, 1 - totalOthers);

    // Determine dominant emotion
    const emotions = Object.entries(newEmotion).slice(0, -2) as [
      string,
      number,
    ][];
    const dominantEmotion = emotions.reduce((max, current) =>
      current[1] > max[1] ? current : max,
    );
    newEmotion.dominant = dominantEmotion[0];

    setCurrentEmotion(newEmotion);
    onEmotionChange?.(newEmotion);
  }, [cameraEnabled, onEmotionChange]);

  // Simulate biofeedback data
  const simulateBiofeedback = useCallback(() => {
    const time = Date.now() / 1000;
    const stressLevel =
      currentEmotion.anger + currentEmotion.fear + currentEmotion.sadness;
    const arousalLevel = currentEmotion.happiness + currentEmotion.surprise;

    const newBiofeedback: BiofeedbackData = {
      heartRate: 60 + arousalLevel * 40 + stressLevel * 30 + Math.sin(time) * 5,
      hrv: 50 - stressLevel * 20 + (Math.random() - 0.5) * 10,
      skinConductance: 0.2 + stressLevel * 0.5 + (Math.random() - 0.5) * 0.1,
      facialTension: stressLevel * 0.8 + (Math.random() - 0.5) * 0.1,
      voiceStress: microphoneEnabled
        ? stressLevel * 0.7 + (Math.random() - 0.5) * 0.1
        : 0,
      cognitiveLoad:
        (stressLevel + arousalLevel) * 0.5 + (Math.random() - 0.5) * 0.1,
    };

    setBiofeedback(newBiofeedback);
    onBiofeedbackChange?.(newBiofeedback);
  }, [currentEmotion, microphoneEnabled, onBiofeedbackChange]);

  // Generate adaptation suggestions based on emotion and biofeedback
  const generateAdaptationSuggestions = useCallback(() => {
    const suggestions: string[] = [];
    const stressLevel =
      currentEmotion.anger + currentEmotion.fear + currentEmotion.sadness;

    if (stressLevel > calibration.stressThreshold) {
      suggestions.push("Reduce task difficulty to lower cognitive load");
      suggestions.push("Suggest breathing exercise to reduce stress");
      suggestions.push("Switch to calming background colors (soft teal, mint)");
    }

    if (currentEmotion.happiness > 0.7) {
      suggestions.push("Increase task difficulty to maintain engagement");
      suggestions.push("Introduce challenging memory exercises");
    }

    if (biofeedback.cognitiveLoad > 0.8) {
      suggestions.push("Take a micro-break to prevent cognitive overload");
      suggestions.push("Switch to simpler task format");
    }

    if (
      currentEmotion.dominant === "neutral" &&
      currentEmotion.happiness < 0.3
    ) {
      suggestions.push("Add motivational elements or rewards");
      suggestions.push("Use energizing colors (light yellow, peach)");
    }

    setAdaptationSuggestions(suggestions);

    if (suggestions.length > 0 && onAdaptationSuggestion) {
      onAdaptationSuggestion(suggestions[0]);
    }
  }, [currentEmotion, biofeedback, calibration, onAdaptationSuggestion]);

  // Calibration process
  const startCalibration = async () => {
    setCalibrationProgress(0);

    toast({
      title: "Calibration Started",
      description:
        "Please remain neutral for 30 seconds while we establish your baseline",
    });

    // Simulate calibration process
    const calibrationInterval = setInterval(() => {
      setCalibrationProgress((prev) => {
        const newProgress = prev + 100 / 30; // 30 second calibration

        if (newProgress >= 100) {
          clearInterval(calibrationInterval);
          setIsCalibrated(true);
          setCalibration((prev) => ({
            ...prev,
            baseline: currentEmotion,
          }));

          toast({
            title: "Calibration Complete",
            description:
              "Personal baseline established for accurate emotion detection",
          });
        }

        return Math.min(100, newProgress);
      });
    }, 1000);
  };

  // Main monitoring loop
  useEffect(() => {
    if (isActive && isCalibrated) {
      const interval = setInterval(() => {
        simulateEmotionDetection();
        simulateBiofeedback();
        generateAdaptationSuggestions();
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [
    isActive,
    isCalibrated,
    simulateEmotionDetection,
    simulateBiofeedback,
    generateAdaptationSuggestions,
  ]);

  const startMonitoring = async () => {
    if (!cameraEnabled) await initializeCamera();
    if (!microphoneEnabled) await initializeMicrophone();

    if (!isCalibrated) {
      await startCalibration();
    }

    setIsActive(true);

    toast({
      title: "Emotion & Biofeedback Monitoring Started",
      description: "Real-time adaptive interface is now active",
    });
  };

  const stopMonitoring = () => {
    setIsActive(false);

    toast({
      title: "Monitoring Stopped",
      description: "Emotion and biofeedback tracking has been paused",
    });
  };

  const getEmotionIcon = (emotion: string) => {
    switch (emotion) {
      case "happiness":
        return <Smile className="h-4 w-4" />;
      case "sadness":
        return <Frown className="h-4 w-4" />;
      case "anger":
        return <AlertCircle className="h-4 w-4" />;
      case "fear":
        return <Eye className="h-4 w-4" />;
      case "surprise":
        return <Zap className="h-4 w-4" />;
      default:
        return <Meh className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Control Panel */}
      <Card className="cognitive-enhancement-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Emotion Recognition & Biofeedback
          </CardTitle>
          <CardDescription>
            Real-time emotion detection and physiological monitoring for
            adaptive cognitive training
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Camera Access</span>
                <Switch
                  checked={cameraEnabled}
                  onCheckedChange={(checked) => {
                    if (checked) initializeCamera();
                    else setCameraEnabled(false);
                  }}
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Microphone Access</span>
                <Switch
                  checked={microphoneEnabled}
                  onCheckedChange={(checked) => {
                    if (checked) initializeMicrophone();
                    else setMicrophoneEnabled(false);
                  }}
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Calibrated</span>
                <Badge variant={isCalibrated ? "default" : "secondary"}>
                  {isCalibrated ? "Yes" : "No"}
                </Badge>
              </div>
            </div>

            <div className="space-y-4">
              {!isCalibrated ? (
                <Button
                  onClick={startCalibration}
                  disabled={!cameraEnabled}
                  className="w-full neural-button"
                >
                  <Settings className="mr-2 h-4 w-4" />
                  Calibrate System
                </Button>
              ) : !isActive ? (
                <Button
                  onClick={startMonitoring}
                  className="w-full neural-button"
                >
                  <Play className="mr-2 h-4 w-4" />
                  Start Monitoring
                </Button>
              ) : (
                <Button
                  onClick={stopMonitoring}
                  variant="outline"
                  className="w-full neural-button"
                >
                  <Pause className="mr-2 h-4 w-4" />
                  Stop Monitoring
                </Button>
              )}
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div
                  className={`w-3 h-3 rounded-full ${isActive ? "bg-green-400 animate-pulse" : "bg-gray-400"}`}
                />
                <span className="text-sm font-medium">
                  {isActive ? "Active" : "Inactive"}
                </span>
              </div>

              {calibrationProgress > 0 && calibrationProgress < 100 && (
                <div className="space-y-2">
                  <div className="text-sm">Calibrating...</div>
                  <Progress value={calibrationProgress} className="h-2" />
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Hidden video element for camera access */}
      <video ref={videoRef} style={{ display: "none" }} autoPlay playsInline />
      <canvas
        ref={canvasRef}
        style={{ display: "none" }}
        width={640}
        height={480}
      />

      {/* Real-time Emotion Analysis */}
      <Card className="cognitive-enhancement-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smile className="h-5 w-5" />
            Real-time Emotion Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-4xl font-bold mb-2 emotion-wave">
                  {getEmotionIcon(currentEmotion.dominant)}
                </div>
                <Badge
                  className={`text-lg px-4 py-2 ${emotionColors[currentEmotion.dominant as keyof typeof emotionColors]}`}
                >
                  {currentEmotion.dominant.toUpperCase()}
                </Badge>
                <div className="text-sm text-gray-600 mt-2">
                  Confidence: {Math.round(currentEmotion.confidence * 100)}%
                </div>
              </div>
            </div>

            <div className="space-y-3">
              {Object.entries(currentEmotion)
                .slice(0, -3)
                .map(([emotion, value]) => (
                  <div key={emotion} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="capitalize flex items-center gap-2">
                        {getEmotionIcon(emotion)}
                        {emotion}
                      </span>
                      <span>{Math.round(value * 100)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <motion.div
                        className={`h-2 rounded-full transition-all duration-500 ${
                          emotion === "happiness"
                            ? "bg-yellow-400"
                            : emotion === "sadness"
                              ? "bg-blue-400"
                              : emotion === "anger"
                                ? "bg-red-400"
                                : emotion === "fear"
                                  ? "bg-purple-400"
                                  : emotion === "surprise"
                                    ? "bg-orange-400"
                                    : emotion === "disgust"
                                      ? "bg-green-400"
                                      : "bg-gray-400"
                        }`}
                        style={{ width: `${value * 100}%` }}
                        animate={{
                          boxShadow:
                            value > 0.5
                              ? "0 0 10px rgba(59, 130, 246, 0.5)"
                              : "none",
                        }}
                      />
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Biofeedback Metrics */}
      <Card className="cognitive-enhancement-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="h-5 w-5" />
            Physiological Biofeedback
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <div className="text-center p-3 bg-white/20 rounded-lg">
              <Heart className="h-6 w-6 mx-auto mb-2 text-red-500" />
              <div className="text-xl font-bold text-red-600">
                {Math.round(biofeedback.heartRate)}
              </div>
              <div className="text-xs text-gray-600">BPM</div>
            </div>

            <div className="text-center p-3 bg-white/20 rounded-lg">
              <Activity className="h-6 w-6 mx-auto mb-2 text-blue-500" />
              <div className="text-xl font-bold text-blue-600">
                {Math.round(biofeedback.hrv)}
              </div>
              <div className="text-xs text-gray-600">HRV (ms)</div>
            </div>

            <div className="text-center p-3 bg-white/20 rounded-lg">
              <Zap className="h-6 w-6 mx-auto mb-2 text-yellow-500" />
              <div className="text-xl font-bold text-yellow-600">
                {Math.round(biofeedback.skinConductance * 100)}%
              </div>
              <div className="text-xs text-gray-600">Skin Conduct.</div>
            </div>

            <div className="text-center p-3 bg-white/20 rounded-lg">
              <Eye className="h-6 w-6 mx-auto mb-2 text-purple-500" />
              <div className="text-xl font-bold text-purple-600">
                {Math.round(biofeedback.facialTension * 100)}%
              </div>
              <div className="text-xs text-gray-600">Facial Tension</div>
            </div>

            <div className="text-center p-3 bg-white/20 rounded-lg">
              <Mic className="h-6 w-6 mx-auto mb-2 text-green-500" />
              <div className="text-xl font-bold text-green-600">
                {Math.round(biofeedback.voiceStress * 100)}%
              </div>
              <div className="text-xs text-gray-600">Voice Stress</div>
            </div>

            <div className="text-center p-3 bg-white/20 rounded-lg">
              <Brain className="h-6 w-6 mx-auto mb-2 text-indigo-500" />
              <div className="text-xl font-bold text-indigo-600">
                {Math.round(biofeedback.cognitiveLoad * 100)}%
              </div>
              <div className="text-xs text-gray-600">Cognitive Load</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Adaptation Suggestions */}
      <AnimatePresence>
        {adaptationSuggestions.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <Card className="cognitive-enhancement-card border-blue-200 bg-blue-50/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-800">
                  <Lightbulb className="h-5 w-5" />
                  AI Adaptation Suggestions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {adaptationSuggestions.map((suggestion, index) => (
                    <Alert key={index} className="border-blue-200 bg-blue-50">
                      <Lightbulb className="h-4 w-4" />
                      <AlertDescription className="text-blue-800">
                        {suggestion}
                      </AlertDescription>
                    </Alert>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Personality & Calibration Settings */}
      <Card className="cognitive-enhancement-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Personality Profile & Calibration
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-semibold">Personality Factors</h4>
              {Object.entries(calibration.personalityFactors).map(
                ([factor, value]) => (
                  <div key={factor} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="capitalize">{factor}</span>
                      <span>{Math.round(value * 100)}%</span>
                    </div>
                    <Slider
                      value={[value * 100]}
                      onValueChange={([newValue]) =>
                        setCalibration((prev) => ({
                          ...prev,
                          personalityFactors: {
                            ...prev.personalityFactors,
                            [factor]: newValue / 100,
                          },
                        }))
                      }
                      max={100}
                      step={5}
                      className="w-full"
                    />
                  </div>
                ),
              )}
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold">Adaptation Thresholds</h4>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Stress Threshold</span>
                  <span>{Math.round(calibration.stressThreshold * 100)}%</span>
                </div>
                <Slider
                  value={[calibration.stressThreshold * 100]}
                  onValueChange={([value]) =>
                    setCalibration((prev) => ({
                      ...prev,
                      stressThreshold: value / 100,
                    }))
                  }
                  max={100}
                  step={5}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Optimal Arousal</span>
                  <span>{Math.round(calibration.optimalArousal * 100)}%</span>
                </div>
                <Slider
                  value={[calibration.optimalArousal * 100]}
                  onValueChange={([value]) =>
                    setCalibration((prev) => ({
                      ...prev,
                      optimalArousal: value / 100,
                    }))
                  }
                  max={100}
                  step={5}
                  className="w-full"
                />
              </div>

              <Button
                onClick={startCalibration}
                disabled={!cameraEnabled}
                className="w-full neural-button"
              >
                <RotateCw className="mr-2 h-4 w-4" />
                Recalibrate Baseline
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
