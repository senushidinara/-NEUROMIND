import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Brain, 
  Cpu, 
  Zap, 
  Target, 
  TrendingUp, 
  Activity, 
  Sparkles,
  Eye,
  Heart,
  Timer,
  Lightbulb,
  Bot,
  Waves,
  TestTube,
  Dna,
  FlaskConical,
  BarChart3,
  Settings,
  Play,
  Pause,
  RotateCw
} from "lucide-react";

interface CognitiveProfile {
  memoryPatterns: Record<string, number>;
  attentionDistribution: Record<string, number>;
  emotionalRegulation: Record<string, number>;
  neuralOscillations: Record<string, number>;
  cognitiveFlexibility: number;
  workingMemoryCapacity: number;
  processingSpeed: number;
  executiveFunction: number;
}

interface AIDecision {
  id: string;
  timestamp: number;
  type: 'exercise_adaptation' | 'difficulty_scaling' | 'content_generation' | 'intervention_recommendation';
  reasoning: string;
  confidence: number;
  expectedOutcome: string;
  actualOutcome?: string;
  effectiveness?: number;
}

interface PredictiveModel {
  cognitiveDecline: {
    probability: number;
    timeframe: string;
    confidenceInterval: [number, number];
  };
  optimalChallengeLevel: {
    current: number;
    predicted: number;
    adaptationRate: number;
  };
  neuralPlasticity: {
    current: number;
    potential: number;
    trajectory: 'improving' | 'stable' | 'declining';
  };
  personalizedRecommendations: Array<{
    type: string;
    description: string;
    priority: number;
    expectedBenefit: number;
  }>;
}

interface AdvancedAIAgentProps {
  cognitiveProfile: CognitiveProfile;
  performanceHistory: Array<any>;
  biofeedbackData: any;
  onRecommendation: (recommendation: any) => void;
  onTaskGeneration: (task: any) => void;
  onDifficultyAdjustment: (adjustment: any) => void;
}

export default function AdvancedAIAgent({
  cognitiveProfile,
  performanceHistory,
  biofeedbackData,
  onRecommendation,
  onTaskGeneration,
  onDifficultyAdjustment
}: AdvancedAIAgentProps) {
  const [agentState, setAgentState] = useState<'idle' | 'analyzing' | 'recommending' | 'adapting'>('idle');
  const [aiDecisions, setAiDecisions] = useState<AIDecision[]>([]);
  const [predictiveModel, setPredictiveModel] = useState<PredictiveModel | null>(null);
  const [autonomousMode, setAutonomousMode] = useState(true);
  const [reasoningProcess, setReasoningProcess] = useState<string[]>([]);
  const [currentAnalysis, setCurrentAnalysis] = useState<string>('');
  const [confidenceLevel, setConfidenceLevel] = useState(0);
  const [learningRate, setLearningRate] = useState(0.1);
  const [adaptationSpeed, setAdaptationSpeed] = useState(0.5);

  const analysisInterval = useRef<NodeJS.Timeout>();
  const decisionHistory = useRef<AIDecision[]>([]);

  // Advanced reasoning engine that simulates multi-agent cognitive processing
  const performCognitiveAnalysis = useCallback(async () => {
    setAgentState('analyzing');
    setCurrentAnalysis('Initializing multi-dimensional cognitive analysis...');
    
    const analysisSteps = [
      'Analyzing neural oscillation patterns and brainwave coherence',
      'Evaluating working memory capacity and attention distribution',
      'Processing emotional regulation patterns and stress responses',
      'Modeling cognitive flexibility and executive function metrics',
      'Computing optimal challenge-skill balance coefficients',
      'Predicting neuroplasticity potential and adaptation rates',
      'Generating personalized intervention recommendations',
      'Optimizing task difficulty and content selection algorithms'
    ];

    for (let i = 0; i < analysisSteps.length; i++) {
      setCurrentAnalysis(analysisSteps[i]);
      setConfidenceLevel((i + 1) / analysisSteps.length * 100);
      await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 400));
      
      setReasoningProcess(prev => [...prev.slice(-4), analysisSteps[i]]);
    }

    // Simulate advanced predictive modeling
    const newPredictiveModel: PredictiveModel = {
      cognitiveDecline: {
        probability: Math.max(0, Math.min(100, 15 + Math.random() * 30 - cognitiveProfile.cognitiveFlexibility * 0.3)),
        timeframe: Math.random() > 0.7 ? '6-12 months' : '1-2 years',
        confidenceInterval: [0.7, 0.9] as [number, number]
      },
      optimalChallengeLevel: {
        current: cognitiveProfile.workingMemoryCapacity * 0.8,
        predicted: Math.min(100, cognitiveProfile.workingMemoryCapacity * 0.8 + learningRate * 10),
        adaptationRate: adaptationSpeed
      },
      neuralPlasticity: {
        current: (cognitiveProfile.cognitiveFlexibility + cognitiveProfile.processingSpeed) / 2,
        potential: Math.min(100, (cognitiveProfile.cognitiveFlexibility + cognitiveProfile.processingSpeed) / 2 + 15),
        trajectory: Math.random() > 0.6 ? 'improving' : 'stable'
      },
      personalizedRecommendations: [
        {
          type: 'Gamma Wave Enhancement',
          description: 'Focused attention training with 40Hz stimulation',
          priority: 0.9,
          expectedBenefit: 0.85
        },
        {
          type: 'Working Memory Expansion',
          description: 'N-back training with emotional interference',
          priority: 0.8,
          expectedBenefit: 0.7
        },
        {
          type: 'Cognitive Flexibility Training',
          description: 'Task-switching with adaptive difficulty',
          priority: 0.75,
          expectedBenefit: 0.8
        },
        {
          type: 'Neurofeedback Optimization',
          description: 'Real-time EEG-based cognitive state regulation',
          priority: 0.95,
          expectedBenefit: 0.9
        }
      ]
    };

    setPredictiveModel(newPredictiveModel);
    setAgentState('recommending');

    // Generate autonomous recommendations
    if (autonomousMode) {
      generateAutonomousRecommendations(newPredictiveModel);
    }

    setAgentState('idle');
  }, [cognitiveProfile, learningRate, adaptationSpeed, autonomousMode]);

  const generateAutonomousRecommendations = useCallback((model: PredictiveModel) => {
    const decision: AIDecision = {
      id: `decision_${Date.now()}`,
      timestamp: Date.now(),
      type: 'exercise_adaptation',
      reasoning: `Based on cognitive flexibility score of ${cognitiveProfile.cognitiveFlexibility.toFixed(1)} and processing speed of ${cognitiveProfile.processingSpeed.toFixed(1)}, recommending difficulty adjustment to optimize neuroplasticity potential.`,
      confidence: 0.85,
      expectedOutcome: `Improved cognitive performance by ${(model.neuralPlasticity.potential - model.neuralPlasticity.current).toFixed(1)}%`
    };

    setAiDecisions(prev => [decision, ...prev.slice(0, 9)]);
    decisionHistory.current.push(decision);

    // Trigger callbacks with AI recommendations
    onRecommendation({
      type: 'autonomous_optimization',
      recommendations: model.personalizedRecommendations,
      confidence: decision.confidence,
      reasoning: decision.reasoning
    });

    // Auto-generate adaptive tasks
    const adaptiveTask = generateAdaptiveTask(model);
    onTaskGeneration(adaptiveTask);

    // Auto-adjust difficulty
    const difficultyAdjustment = calculateOptimalDifficulty(model);
    onDifficultyAdjustment(difficultyAdjustment);
  }, [cognitiveProfile, onRecommendation, onTaskGeneration, onDifficultyAdjustment]);

  const generateAdaptiveTask = (model: PredictiveModel) => {
    const taskTypes = [
      'multi_modal_memory',
      'emotional_working_memory',
      'cognitive_flexibility_switching',
      'attention_inhibition_control',
      'spatial_temporal_reasoning',
      'neurofeedback_regulation'
    ];

    const selectedType = taskTypes[Math.floor(Math.random() * taskTypes.length)];
    
    return {
      type: selectedType,
      difficulty: model.optimalChallengeLevel.predicted,
      adaptationEnabled: true,
      neuralTargets: ['prefrontal_cortex', 'hippocampus', 'anterior_cingulate'],
      expectedDuration: 180000, // 3 minutes
      realTimeAdaptation: true,
      biofeedbackIntegration: true,
      gamificationElements: ['progression_tracking', 'achievement_unlocks', 'neural_visualization']
    };
  };

  const calculateOptimalDifficulty = (model: PredictiveModel) => {
    return {
      baseLevel: model.optimalChallengeLevel.predicted,
      adaptationRate: model.optimalChallengeLevel.adaptationRate,
      personalizedFactors: {
        stressLevel: biofeedbackData?.cognitiveLoad || 0.5,
        attentionLevel: cognitiveProfile.attentionDistribution?.focused || 0.7,
        energyLevel: biofeedbackData?.heartRate ? (biofeedbackData.heartRate - 60) / 40 : 0.6
      },
      realTimeAdjustment: true
    };
  };

  // Start autonomous analysis loop
  useEffect(() => {
    if (autonomousMode) {
      analysisInterval.current = setInterval(() => {
        performCognitiveAnalysis();
      }, 30000); // Analyze every 30 seconds

      // Initial analysis
      performCognitiveAnalysis();
    }

    return () => {
      if (analysisInterval.current) {
        clearInterval(analysisInterval.current);
      }
    };
  }, [autonomousMode, performCognitiveAnalysis]);

  const toggleAutonomousMode = () => {
    setAutonomousMode(!autonomousMode);
    if (!autonomousMode) {
      performCognitiveAnalysis();
    }
  };

  return (
    <div className="space-y-6">
      {/* AI Agent Control Panel */}
      <Card className="bg-gradient-to-br from-indigo-50/80 to-purple-50/80 backdrop-blur-sm border-indigo-200/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-indigo-900">
              <Bot className="w-5 h-5" />
              Autonomous AI Cognitive Director
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge 
                variant={agentState === 'idle' ? 'default' : 'secondary'}
                className="bg-indigo-100 text-indigo-800 border-indigo-200"
              >
                {agentState.toUpperCase()}
              </Badge>
              <Button
                onClick={toggleAutonomousMode}
                variant={autonomousMode ? 'default' : 'outline'}
                size="sm"
                className="bg-indigo-600 hover:bg-indigo-700 text-white border-indigo-300"
              >
                {autonomousMode ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                {autonomousMode ? 'Pause' : 'Start'} Autonomous Mode
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Real-time Analysis */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Brain className="w-4 h-4 text-indigo-600" />
                <span className="font-medium text-indigo-900">Real-time Analysis</span>
              </div>
              <div className="space-y-2">
                <Progress value={confidenceLevel} className="h-2" />
                <p className="text-xs text-indigo-700 leading-relaxed">
                  {currentAnalysis}
                </p>
              </div>
            </div>

            {/* Agent Statistics */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-purple-600" />
                <span className="font-medium text-purple-900">Agent Performance</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-white/60 p-2 rounded">
                  <div className="text-purple-600 font-medium">Decisions</div>
                  <div className="text-purple-900">{aiDecisions.length}</div>
                </div>
                <div className="bg-white/60 p-2 rounded">
                  <div className="text-purple-600 font-medium">Accuracy</div>
                  <div className="text-purple-900">{(confidenceLevel).toFixed(1)}%</div>
                </div>
                <div className="bg-white/60 p-2 rounded">
                  <div className="text-purple-600 font-medium">Learning</div>
                  <div className="text-purple-900">{(learningRate * 100).toFixed(1)}%</div>
                </div>
                <div className="bg-white/60 p-2 rounded">
                  <div className="text-purple-600 font-medium">Adaptation</div>
                  <div className="text-purple-900">{(adaptationSpeed * 100).toFixed(1)}%</div>
                </div>
              </div>
            </div>

            {/* Control Parameters */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Settings className="w-4 h-4 text-emerald-600" />
                <span className="font-medium text-emerald-900">Agent Parameters</span>
              </div>
              <div className="space-y-2">
                <div>
                  <label className="text-xs text-emerald-700">Learning Rate</label>
                  <input
                    type="range"
                    min="0.01"
                    max="0.5"
                    step="0.01"
                    value={learningRate}
                    onChange={(e) => setLearningRate(parseFloat(e.target.value))}
                    className="w-full h-1 bg-emerald-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <span className="text-xs text-emerald-600">{(learningRate * 100).toFixed(1)}%</span>
                </div>
                <div>
                  <label className="text-xs text-emerald-700">Adaptation Speed</label>
                  <input
                    type="range"
                    min="0.1"
                    max="1.0"
                    step="0.1"
                    value={adaptationSpeed}
                    onChange={(e) => setAdaptationSpeed(parseFloat(e.target.value))}
                    className="w-full h-1 bg-emerald-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <span className="text-xs text-emerald-600">{(adaptationSpeed * 100).toFixed(0)}%</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Predictive Modeling Dashboard */}
      {predictiveModel && (
        <Card className="bg-gradient-to-br from-emerald-50/80 to-teal-50/80 backdrop-blur-sm border-emerald-200/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-emerald-900">
              <TrendingUp className="w-5 h-5" />
              Predictive Cognitive Modeling
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Cognitive Decline Prediction */}
              <div className="bg-white/60 p-4 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-4 h-4 text-red-500" />
                  <span className="font-medium text-gray-900">Cognitive Risk</span>
                </div>
                <div className="space-y-2">
                  <Progress 
                    value={predictiveModel.cognitiveDecline.probability} 
                    className="h-2"
                  />
                  <div className="text-xs text-gray-600">
                    <div>{predictiveModel.cognitiveDecline.probability.toFixed(1)}% probability</div>
                    <div>Timeframe: {predictiveModel.cognitiveDecline.timeframe}</div>
                  </div>
                </div>
              </div>

              {/* Optimal Challenge Level */}
              <div className="bg-white/60 p-4 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-yellow-500" />
                  <span className="font-medium text-gray-900">Challenge Level</span>
                </div>
                <div className="space-y-2">
                  <Progress 
                    value={predictiveModel.optimalChallengeLevel.predicted} 
                    className="h-2"
                  />
                  <div className="text-xs text-gray-600">
                    <div>Current: {predictiveModel.optimalChallengeLevel.current.toFixed(1)}%</div>
                    <div>Optimal: {predictiveModel.optimalChallengeLevel.predicted.toFixed(1)}%</div>
                  </div>
                </div>
              </div>

              {/* Neural Plasticity */}
              <div className="bg-white/60 p-4 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Brain className="w-4 h-4 text-purple-500" />
                  <span className="font-medium text-gray-900">Neuroplasticity</span>
                </div>
                <div className="space-y-2">
                  <Progress 
                    value={predictiveModel.neuralPlasticity.potential} 
                    className="h-2"
                  />
                  <div className="text-xs text-gray-600">
                    <div>Current: {predictiveModel.neuralPlasticity.current.toFixed(1)}%</div>
                    <div>Trajectory: {predictiveModel.neuralPlasticity.trajectory}</div>
                  </div>
                </div>
              </div>

              {/* Recommendations Count */}
              <div className="bg-white/60 p-4 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Lightbulb className="w-4 h-4 text-blue-500" />
                  <span className="font-medium text-gray-900">Recommendations</span>
                </div>
                <div className="space-y-2">
                  <div className="text-2xl font-bold text-blue-600">
                    {predictiveModel.personalizedRecommendations.length}
                  </div>
                  <div className="text-xs text-gray-600">
                    Active interventions
                  </div>
                </div>
              </div>
            </div>

            {/* Personalized Recommendations */}
            <div className="mt-6">
              <h4 className="font-medium text-emerald-900 mb-3">AI-Generated Recommendations</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {predictiveModel.personalizedRecommendations.map((rec, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white/60 p-3 rounded-lg border border-emerald-200/30"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="font-medium text-gray-900 text-sm">{rec.type}</div>
                        <div className="text-xs text-gray-600 mt-1">{rec.description}</div>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="outline" className="text-xs">
                            Priority: {(rec.priority * 100).toFixed(0)}%
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            Benefit: {(rec.expectedBenefit * 100).toFixed(0)}%
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Reasoning Process Visualization */}
      <Card className="bg-gradient-to-br from-gray-50/80 to-slate-50/80 backdrop-blur-sm border-gray-200/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-900">
            <Cpu className="w-5 h-5" />
            Real-time Reasoning Process
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <AnimatePresence>
              {reasoningProcess.map((step, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-2 p-2 bg-white/60 rounded border border-gray-200/30"
                >
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
                  <span className="text-sm text-gray-700">{step}</span>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </CardContent>
      </Card>

      {/* Recent AI Decisions */}
      <Card className="bg-gradient-to-br from-blue-50/80 to-cyan-50/80 backdrop-blur-sm border-blue-200/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-900">
            <Activity className="w-5 h-5" />
            Recent AI Decisions & Adaptations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {aiDecisions.map((decision, index) => (
              <motion.div
                key={decision.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/60 p-3 rounded-lg border border-blue-200/30"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge 
                        variant="outline" 
                        className="text-xs bg-blue-100 text-blue-800 border-blue-200"
                      >
                        {decision.type.replace('_', ' ').toUpperCase()}
                      </Badge>
                      <span className="text-xs text-gray-500">
                        {new Date(decision.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="text-sm text-gray-900 mb-2">{decision.reasoning}</div>
                    <div className="text-xs text-gray-600">
                      Expected: {decision.expectedOutcome}
                    </div>
                  </div>
                  <div className="ml-3">
                    <div className="text-xs text-gray-500">Confidence</div>
                    <div className="text-lg font-bold text-blue-600">
                      {(decision.confidence * 100).toFixed(0)}%
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
