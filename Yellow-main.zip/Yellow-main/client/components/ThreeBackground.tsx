import { useRef, useEffect, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Sphere, Box, Float, Environment, MeshDistortMaterial, Stars } from '@react-three/drei';
import { motion } from 'framer-motion';
import * as THREE from 'three';

function FloatingGeometry({ position, color, shape = 'sphere' }: { 
  position: [number, number, number]; 
  color: string; 
  shape?: 'sphere' | 'box' | 'torus' 
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.5) * 0.2;
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.7) * 0.3;
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime + position[0]) * 0.5;
    }
  });

  const Component = shape === 'sphere' ? Sphere : shape === 'box' ? Box : Sphere;

  return (
    <Float speed={2} rotationIntensity={0.2} floatIntensity={0.3}>
      <Component
        ref={meshRef}
        position={position}
        args={shape === 'sphere' ? [0.8, 32, 32] : [1.2, 1.2, 1.2]}
        onPointerEnter={() => setHovered(true)}
        onPointerLeave={() => setHovered(false)}
      >
        <MeshDistortMaterial
          color={color}
          attach="material"
          distort={hovered ? 0.6 : 0.3}
          speed={hovered ? 5 : 2}
          roughness={0.1}
          metalness={0.8}
          transparent
          opacity={0.7}
        />
      </Component>
    </Float>
  );
}

function ParticleField() {
  const pointsRef = useRef<THREE.Points>(null);
  const particleCount = 1000;

  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.1) * 0.1;
      pointsRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.05) * 0.2;
    }
  });

  const positions = new Float32Array(particleCount * 3);
  const colors = new Float32Array(particleCount * 3);

  for (let i = 0; i < particleCount; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 50;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 50;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 50;

    const color = new THREE.Color();
    color.setHSL(0.6 + Math.random() * 0.3, 0.7, 0.8);
    colors[i * 3] = color.r;
    colors[i * 3 + 1] = color.g;
    colors[i * 3 + 2] = color.b;
  }

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          array={positions}
          count={particleCount}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          array={colors}
          count={particleCount}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial size={0.05} vertexColors transparent opacity={0.6} />
    </points>
  );
}

function CameraController() {
  const { camera } = useThree();

  useFrame((state) => {
    camera.position.x = Math.sin(state.clock.elapsedTime * 0.1) * 2;
    camera.position.z = 10 + Math.sin(state.clock.elapsedTime * 0.05) * 2;
    camera.lookAt(0, 0, 0);
  });

  return null;
}

function ThreeScene() {
  const geometries = [
    { position: [-8, 2, -5] as [number, number, number], color: "#ff6b9d", shape: "sphere" as const },
    { position: [8, -2, -3] as [number, number, number], color: "#4ecdc4", shape: "box" as const },
    { position: [-4, -3, 2] as [number, number, number], color: "#95e1d3", shape: "sphere" as const },
    { position: [6, 3, 1] as [number, number, number], color: "#fce38a", shape: "box" as const },
    { position: [0, 4, -8] as [number, number, number], color: "#c3aed6", shape: "sphere" as const },
    { position: [-6, 1, 5] as [number, number, number], color: "#ff8a80", shape: "box" as const },
  ];

  return (
    <>
      <Environment preset="sunset" />
      <ambientLight intensity={0.4} />
      <directionalLight position={[10, 10, 5]} intensity={1} />
      <pointLight position={[-10, -10, -10]} intensity={0.8} color="#4ecdc4" />
      <pointLight position={[10, 10, 10]} intensity={0.8} color="#ff6b9d" />
      
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
      <ParticleField />
      
      {geometries.map((geo, index) => (
        <FloatingGeometry
          key={index}
          position={geo.position}
          color={geo.color}
          shape={geo.shape}
        />
      ))}
      
      <CameraController />
    </>
  );
}

interface ThreeBackgroundProps {
  className?: string;
  intensity?: number;
}

export default function ThreeBackground({ className = "", intensity = 1 }: ThreeBackgroundProps) {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <motion.div
      className={`fixed inset-0 -z-10 ${className}`}
      initial={{ opacity: 0 }}
      animate={{ opacity: intensity }}
      transition={{ duration: 2 }}
    >
      {isLoaded && (
        <Canvas
          camera={{
            position: [0, 0, 10],
            fov: 60,
          }}
          style={{ 
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            filter: `blur(${2 - intensity}px)`,
          }}
          dpr={window.devicePixelRatio}
          gl={{ 
            antialias: true, 
            alpha: true,
            powerPreference: 'high-performance',
          }}
        >
          <ThreeScene />
        </Canvas>
      )}
      
      {/* Overlay gradient for better text readability */}
      <div 
        className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-black/20 pointer-events-none"
        style={{ opacity: 1 - intensity * 0.3 }}
      />
    </motion.div>
  );
}
