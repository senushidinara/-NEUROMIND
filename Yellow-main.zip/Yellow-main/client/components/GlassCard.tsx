import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glow?: boolean;
  gradient?: 'purple' | 'blue' | 'pink' | 'cyan' | 'emerald' | 'amber';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  onClick?: () => void;
}

const gradients = {
  purple: 'from-purple-500/20 to-pink-500/20',
  blue: 'from-blue-500/20 to-cyan-500/20',
  pink: 'from-pink-500/20 to-rose-500/20',
  cyan: 'from-cyan-500/20 to-teal-500/20',
  emerald: 'from-emerald-500/20 to-green-500/20',
  amber: 'from-amber-500/20 to-yellow-500/20',
};

const glows = {
  purple: 'shadow-purple-500/25',
  blue: 'shadow-blue-500/25',
  pink: 'shadow-pink-500/25',
  cyan: 'shadow-cyan-500/25',
  emerald: 'shadow-emerald-500/25',
  amber: 'shadow-amber-500/25',
};

const sizes = {
  sm: 'p-4',
  md: 'p-6',
  lg: 'p-8',
  xl: 'p-10',
};

export default function GlassCard({
  children,
  className = '',
  hover = true,
  glow = false,
  gradient = 'purple',
  size = 'md',
  onClick
}: GlassCardProps) {
  return (
    <motion.div
      className={cn(
        // Base glass styling
        'backdrop-blur-xl bg-white/10 dark:bg-black/10',
        'border border-white/20 dark:border-white/10',
        'rounded-2xl shadow-xl',
        
        // Size
        sizes[size],
        
        // Gradient overlay
        `bg-gradient-to-br ${gradients[gradient]}`,
        
        // Glow effect
        glow && `shadow-2xl ${glows[gradient]}`,
        
        // Interactive styles
        onClick && 'cursor-pointer',
        hover && 'transition-all duration-300',
        
        className
      )}
      whileHover={hover ? {
        scale: 1.02,
        y: -4,
        boxShadow: glow 
          ? '0 25px 50px -12px rgba(0, 0, 0, 0.25), 0 0 40px rgba(147, 51, 234, 0.3)'
          : '0 25px 50px -12px rgba(0, 0, 0, 0.25)'
      } : undefined}
      whileTap={onClick ? { scale: 0.98 } : undefined}
      onClick={onClick}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
    >
      {/* Inner glow effect */}
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-white/5 to-white/10 opacity-50" />
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
      
      {/* Animated border highlight */}
      <motion.div
        className="absolute inset-0 rounded-2xl border border-white/30 opacity-0"
        animate={hover ? {
          opacity: [0, 0.3, 0],
        } : undefined}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />
    </motion.div>
  );
}

// Specialized glass components
export function GlassButton({
  children,
  onClick,
  className = '',
  variant = 'purple',
  disabled = false
}: {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  variant?: 'purple' | 'blue' | 'pink' | 'cyan' | 'emerald' | 'amber';
  disabled?: boolean;
}) {
  return (
    <motion.button
      className={cn(
        'backdrop-blur-xl bg-white/10 dark:bg-black/10',
        'border border-white/20 dark:border-white/10',
        'rounded-xl px-6 py-3 shadow-lg',
        `bg-gradient-to-r ${gradients[variant]}`,
        'text-white font-medium transition-all duration-300',
        'hover:shadow-xl hover:border-white/30',
        disabled && 'opacity-50 cursor-not-allowed',
        className
      )}
      whileHover={!disabled ? { scale: 1.05, y: -2 } : undefined}
      whileTap={!disabled ? { scale: 0.95 } : undefined}
      onClick={onClick}
      disabled={disabled}
    >
      <div className="relative z-10">{children}</div>
      <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-white/5 to-white/10 opacity-50" />
    </motion.button>
  );
}

export function GlassInput({
  placeholder,
  value,
  onChange,
  className = '',
  type = 'text'
}: {
  placeholder?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  className?: string;
  type?: string;
}) {
  return (
    <div className={cn('relative', className)}>
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className={cn(
          'w-full backdrop-blur-xl bg-white/10 dark:bg-black/10',
          'border border-white/20 dark:border-white/10',
          'rounded-xl px-4 py-3 shadow-lg',
          'text-white placeholder:text-white/60',
          'focus:outline-none focus:ring-2 focus:ring-purple-500/50',
          'focus:border-white/30 transition-all duration-300'
        )}
      />
      <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-white/5 to-white/10 opacity-30 pointer-events-none" />
    </div>
  );
}
