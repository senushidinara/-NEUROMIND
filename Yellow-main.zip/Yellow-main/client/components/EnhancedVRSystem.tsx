import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, Text, Sphere, Box, Plane, Environment, Effects } from "@react-three/drei";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Eye,
  Monitor,
  Headphones,
  Gamepad2,
  Globe,
  Layers3,
  Sparkles,
  Target,
  Brain,
  Heart,
  Zap,
  Activity,
  RotateCw,
  Play,
  Pause,
  Square,
  Maximize,
  Volume2,
  VolumeX,
  Settings,
  Sliders,
  Brush,
  Contrast,
  Timer,
  TrendingUp,
  BarChart3,
  Camera,
  Mic,
  Crosshair,
  Focus,
  TestTube,
  FlaskConical,
  Waves,
  Sunrise,
  Sunset,
  Moon,
  Sun
} from "lucide-react";
import * as THREE from "three";

interface EmotionEnvironmentMapping {
  happiness: { colors: string[], lighting: number, particles: number, dynamics: string };
  sadness: { colors: string[], lighting: number, particles: number, dynamics: string };
  anger: { colors: string[], lighting: number, particles: number, dynamics: string };
  fear: { colors: string[], lighting: number, particles: number, dynamics: string };
  surprise: { colors: string[], lighting: number, particles: number, dynamics: string };
  neutral: { colors: string[], lighting: number, particles: number, dynamics: string };
}

interface VREnvironment {
  id: string;
  name: string;
  type: 'memory_palace' | 'neural_garden' | 'cognitive_maze' | 'meditation_space' | 'training_arena' | 'collaborative_world';
  cognitiveTargets: string[];
  adaptiveFeatures: string[];
  emotionResponsiveness: number;
  proceduralComplexity: number;
  biofeedbackIntegration: boolean;
  gamificationElements: string[];
}

interface BiofeedbackSensor {
  type: 'eeg' | 'heart_rate' | 'gsr' | 'eye_tracking' | 'facial_recognition' | 'voice_analysis';
  status: 'connected' | 'disconnected' | 'calibrating' | 'error';
  quality: number;
  lastReading: number;
  calibrationData: any;
}

interface ProceduralParameters {
  complexity: number;
  emotionalValence: number;
  cognitiveLoad: number;
  adaptationRate: number;
  personalizedFactors: Record<string, number>;
  environmentalStimuli: {
    lighting: { intensity: number, color: string, dynamics: string };
    audio: { volume: number, frequency: string, spatialAudio: boolean };
    haptics: { intensity: number, patterns: string[], adaptive: boolean };
    visuals: { density: number, motion: string, interactivity: number };
  };
}

// Emotion-responsive particle system component
function EmotionParticles({ emotion, intensity }: { emotion: string, intensity: number }) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const particleCount = useMemo(() => Math.floor(intensity * 1000), [intensity]);
  
  const particles = useMemo(() => {
    const temp = [];
    for (let i = 0; i < particleCount; i++) {
      temp.push({
        position: [
          (Math.random() - 0.5) * 20,
          (Math.random() - 0.5) * 20,
          (Math.random() - 0.5) * 20
        ],
        velocity: [
          (Math.random() - 0.5) * 0.1,
          (Math.random() - 0.5) * 0.1,
          (Math.random() - 0.5) * 0.1
        ],
        color: getEmotionColor(emotion)
      });
    }
    return temp;
  }, [particleCount, emotion]);

  useFrame((state, delta) => {
    if (meshRef.current) {
      particles.forEach((particle, i) => {
        const matrix = new THREE.Matrix4();
        particle.position[0] += particle.velocity[0];
        particle.position[1] += particle.velocity[1];
        particle.position[2] += particle.velocity[2];
        
        // Emotion-based movement patterns
        if (emotion === 'happiness') {
          particle.position[1] += Math.sin(state.clock.elapsedTime + i) * 0.01;
        } else if (emotion === 'anger') {
          particle.velocity[0] += (Math.random() - 0.5) * 0.001;
          particle.velocity[2] += (Math.random() - 0.5) * 0.001;
        } else if (emotion === 'sadness') {
          particle.position[1] -= 0.005;
        }
        
        // Reset particles that go out of bounds
        if (Math.abs(particle.position[0]) > 10) particle.position[0] = (Math.random() - 0.5) * 20;
        if (Math.abs(particle.position[1]) > 10) particle.position[1] = (Math.random() - 0.5) * 20;
        if (Math.abs(particle.position[2]) > 10) particle.position[2] = (Math.random() - 0.5) * 20;
        
        matrix.setPosition(particle.position[0], particle.position[1], particle.position[2]);
        meshRef.current!.setMatrixAt(i, matrix);
      });
      meshRef.current.instanceMatrix.needsUpdate = true;
    }
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, particleCount]}>
      <sphereGeometry args={[0.02, 8, 8]} />
      <meshBasicMaterial color={getEmotionColor(emotion)} transparent opacity={0.6} />
    </instancedMesh>
  );
}

// Procedural environment generator component
function ProceduralEnvironment({ parameters, emotion }: { parameters: ProceduralParameters, emotion: string }) {
  const groupRef = useRef<THREE.Group>(null);
  
  const environmentElements = useMemo(() => {
    const elements = [];
    const complexity = parameters.complexity;
    const count = Math.floor(complexity * 50);
    
    for (let i = 0; i < count; i++) {
      elements.push({
        id: i,
        type: Math.random() > 0.5 ? 'box' : 'sphere',
        position: [
          (Math.random() - 0.5) * 30,
          (Math.random() - 0.5) * 10 + 5,
          (Math.random() - 0.5) * 30
        ],
        scale: Math.random() * 2 + 0.5,
        color: getEmotionColor(emotion),
        interactivity: Math.random() * parameters.personalizedFactors.attention || 0.5
      });
    }
    return elements;
  }, [parameters.complexity, emotion, parameters.personalizedFactors.attention]);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += 0.001 * parameters.adaptationRate;
    }
  });

  return (
    <group ref={groupRef}>
      {environmentElements.map((element) => (
        <mesh key={element.id} position={element.position as [number, number, number]} scale={element.scale}>
          {element.type === 'box' ? (
            <boxGeometry args={[1, 1, 1]} />
          ) : (
            <sphereGeometry args={[0.5, 16, 16]} />
          )}
          <meshStandardMaterial 
            color={element.color} 
            transparent 
            opacity={0.7 + element.interactivity * 0.3}
            emissive={element.color}
            emissiveIntensity={0.2}
          />
        </mesh>
      ))}
    </group>
  );
}

// Adaptive lighting component based on biofeedback
function BiofeedbackLighting({ heartRate, stressLevel, emotion }: { heartRate: number, stressLevel: number, emotion: string }) {
  const lightRef = useRef<THREE.DirectionalLight>(null);
  
  useFrame((state) => {
    if (lightRef.current) {
      // Adapt lighting based on heart rate and stress
      const intensity = Math.max(0.3, Math.min(2.0, (heartRate - 60) / 40 + (1 - stressLevel)));
      lightRef.current.intensity = intensity;
      
      // Color temperature based on emotion
      const color = new THREE.Color(getEmotionColor(emotion));
      lightRef.current.color = color;
      
      // Subtle pulsing based on heart rate
      lightRef.current.intensity += Math.sin(state.clock.elapsedTime * (heartRate / 60) * 2) * 0.1;
    }
  });

  return (
    <>
      <directionalLight ref={lightRef} position={[10, 10, 5]} />
      <ambientLight intensity={0.2} />
    </>
  );
}

// Neural wave visualization component
function NeuralWaveVisualization({ brainwaves }: { brainwaves: Record<string, number> }) {
  const meshRefs = useRef<{ [key: string]: THREE.Mesh }>({});
  
  useFrame((state) => {
    Object.entries(brainwaves).forEach(([wave, amplitude], index) => {
      const mesh = meshRefs.current[wave];
      if (mesh) {
        const frequency = getWaveFrequency(wave);
        mesh.position.y = Math.sin(state.clock.elapsedTime * frequency) * amplitude * 2;
        mesh.material.opacity = amplitude;
      }
    });
  });

  return (
    <group position={[0, 5, 0]}>
      {Object.entries(brainwaves).map(([wave, amplitude], index) => (
        <mesh
          key={wave}
          ref={(el) => { if (el) meshRefs.current[wave] = el; }}
          position={[index * 2 - 4, 0, 0]}
        >
          <ringGeometry args={[0.5, 1, 16]} />
          <meshBasicMaterial 
            color={getWaveColor(wave)} 
            transparent 
            opacity={amplitude}
          />
        </mesh>
      ))}
    </group>
  );
}

// Main VR Scene component
function VRScene({ emotion, biofeedback, cognitiveState, proceduralParams }: {
  emotion: string,
  biofeedback: any,
  cognitiveState: any,
  proceduralParams: ProceduralParameters
}) {
  return (
    <>
      <BiofeedbackLighting 
        heartRate={biofeedback.heartRate} 
        stressLevel={biofeedback.voiceStress} 
        emotion={emotion} 
      />
      
      <EmotionParticles emotion={emotion} intensity={0.8} />
      
      <ProceduralEnvironment parameters={proceduralParams} emotion={emotion} />
      
      <NeuralWaveVisualization brainwaves={{
        alpha: cognitiveState.focusLevel * 0.8,
        beta: cognitiveState.cognitiveLoad,
        gamma: cognitiveState.accuracy,
        theta: 1 - cognitiveState.stressLevel,
        delta: Math.random() * 0.3
      }} />

      {/* Ground plane */}
      <Plane args={[50, 50]} rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]}>
        <meshStandardMaterial color={getEmotionColor(emotion)} transparent opacity={0.3} />
      </Plane>

      <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} />
      <Environment preset="sunset" />
    </>
  );
}

// Helper functions
function getEmotionColor(emotion: string): string {
  const colors: Record<string, string> = {
    happiness: '#FFD700',
    sadness: '#4682B4',
    anger: '#DC143C',
    fear: '#800080',
    surprise: '#FF8C00',
    disgust: '#9ACD32',
    neutral: '#778899'
  };
  return colors[emotion] || colors.neutral;
}

function getWaveFrequency(wave: string): number {
  const frequencies: Record<string, number> = {
    delta: 2,
    theta: 6,
    alpha: 10,
    beta: 20,
    gamma: 40
  };
  return frequencies[wave] || 10;
}

function getWaveColor(wave: string): string {
  const colors: Record<string, string> = {
    delta: '#FF0000',
    theta: '#FF8000',
    alpha: '#FFFF00',
    beta: '#00FF00',
    gamma: '#0080FF'
  };
  return colors[wave] || '#FFFFFF';
}

interface EnhancedVRSystemProps {
  currentEmotion: any;
  biofeedbackData: any;
  cognitiveState: any;
  onEnvironmentChange: (environmentId: string) => void;
  onBiofeedbackCalibration: (sensorType: string) => void;
}

export default function EnhancedVRSystem({
  currentEmotion,
  biofeedbackData,
  cognitiveState,
  onEnvironmentChange,
  onBiofeedbackCalibration
}: EnhancedVRSystemProps) {
  const [vrMode, setVrMode] = useState<'desktop' | 'vr' | 'ar'>('desktop');
  const [currentEnvironment, setCurrentEnvironment] = useState<string>('neural_garden');
  const [biofeedbackSensors, setBiofeedbackSensors] = useState<BiofeedbackSensor[]>([]);
  const [proceduralParams, setProceduralParams] = useState<ProceduralParameters>({
    complexity: 0.7,
    emotionalValence: 0.6,
    cognitiveLoad: 0.5,
    adaptationRate: 0.8,
    personalizedFactors: {
      attention: 0.7,
      memory: 0.8,
      processing: 0.6
    },
    environmentalStimuli: {
      lighting: { intensity: 1.0, color: '#FFFFFF', dynamics: 'adaptive' },
      audio: { volume: 0.7, frequency: 'gamma', spatialAudio: true },
      haptics: { intensity: 0.5, patterns: ['heartbeat', 'breath'], adaptive: true },
      visuals: { density: 0.8, motion: 'organic', interactivity: 0.9 }
    }
  });
  const [isCalibrating, setIsCalibrating] = useState<boolean>(false);
  const [adaptationEnabled, setAdaptationEnabled] = useState<boolean>(true);
  const [vrEnvironments, setVrEnvironments] = useState<VREnvironment[]>([]);

  // Initialize VR environments
  useEffect(() => {
    const environments: VREnvironment[] = [
      {
        id: 'neural_garden',
        name: 'Neural Garden',
        type: 'neural_garden',
        cognitiveTargets: ['memory', 'attention', 'creativity'],
        adaptiveFeatures: ['emotion-responsive flora', 'synapse pathways', 'memory trees'],
        emotionResponsiveness: 0.95,
        proceduralComplexity: 0.8,
        biofeedbackIntegration: true,
        gamificationElements: ['growth tracking', 'neural connections', 'memory fruits']
      },
      {
        id: 'memory_palace',
        name: 'Memory Palace',
        type: 'memory_palace',
        cognitiveTargets: ['memory', 'spatial awareness', 'recall'],
        adaptiveFeatures: ['room generation', 'object placement', 'pathway optimization'],
        emotionResponsiveness: 0.7,
        proceduralComplexity: 0.9,
        biofeedbackIntegration: true,
        gamificationElements: ['palace expansion', 'memory artifacts', 'recall challenges']
      },
      {
        id: 'cognitive_maze',
        name: 'Cognitive Maze',
        type: 'cognitive_maze',
        cognitiveTargets: ['problem solving', 'executive function', 'planning'],
        adaptiveFeatures: ['dynamic pathways', 'puzzle adaptation', 'complexity scaling'],
        emotionResponsiveness: 0.6,
        proceduralComplexity: 0.95,
        biofeedbackIntegration: true,
        gamificationElements: ['maze mastery', 'solution paths', 'cognitive keys']
      },
      {
        id: 'meditation_space',
        name: 'Meditation Space',
        type: 'meditation_space',
        cognitiveTargets: ['stress reduction', 'emotional regulation', 'mindfulness'],
        adaptiveFeatures: ['breathing visualization', 'calming elements', 'stress response'],
        emotionResponsiveness: 0.99,
        proceduralComplexity: 0.3,
        biofeedbackIntegration: true,
        gamificationElements: ['serenity levels', 'mindfulness achievements', 'peace progress']
      },
      {
        id: 'training_arena',
        name: 'Training Arena',
        type: 'training_arena',
        cognitiveTargets: ['reaction time', 'coordination', 'performance'],
        adaptiveFeatures: ['challenge generation', 'difficulty scaling', 'performance tracking'],
        emotionResponsiveness: 0.5,
        proceduralComplexity: 0.85,
        biofeedbackIntegration: true,
        gamificationElements: ['arena levels', 'performance records', 'skill mastery']
      },
      {
        id: 'collaborative_world',
        name: 'Collaborative World',
        type: 'collaborative_world',
        cognitiveTargets: ['social cognition', 'collaboration', 'communication'],
        adaptiveFeatures: ['social dynamics', 'group challenges', 'shared experiences'],
        emotionResponsiveness: 0.8,
        proceduralComplexity: 0.75,
        biofeedbackIntegration: true,
        gamificationElements: ['team achievements', 'social connections', 'collaborative projects']
      }
    ];
    setVrEnvironments(environments);
  }, []);

  // Initialize biofeedback sensors
  useEffect(() => {
    const sensors: BiofeedbackSensor[] = [
      {
        type: 'eeg',
        status: 'connected',
        quality: 0.87,
        lastReading: Date.now(),
        calibrationData: { alpha: 0.7, beta: 0.6, gamma: 0.4, theta: 0.3, delta: 0.2 }
      },
      {
        type: 'heart_rate',
        status: 'connected',
        quality: 0.94,
        lastReading: Date.now(),
        calibrationData: { baseline: 70, variability: 45 }
      },
      {
        type: 'gsr',
        status: 'connected',
        quality: 0.82,
        lastReading: Date.now(),
        calibrationData: { baseline: 0.3, sensitivity: 0.8 }
      },
      {
        type: 'eye_tracking',
        status: 'calibrating',
        quality: 0.76,
        lastReading: Date.now(),
        calibrationData: { pupilDilation: 3.2, gazeStability: 0.9 }
      },
      {
        type: 'facial_recognition',
        status: 'connected',
        quality: 0.91,
        lastReading: Date.now(),
        calibrationData: { emotionAccuracy: 0.89, microExpressions: true }
      },
      {
        type: 'voice_analysis',
        status: 'disconnected',
        quality: 0.0,
        lastReading: 0,
        calibrationData: { stressIndicators: [], pitchVariability: 0 }
      }
    ];
    setBiofeedbackSensors(sensors);
  }, []);

  // Real-time adaptation based on biofeedback
  useEffect(() => {
    if (adaptationEnabled && biofeedbackData) {
      const newParams = { ...proceduralParams };
      
      // Adapt complexity based on cognitive load
      newParams.complexity = Math.max(0.1, Math.min(1.0, 1.0 - biofeedbackData.cognitiveLoad));
      
      // Adapt emotional valence based on stress level
      newParams.emotionalValence = Math.max(0.0, Math.min(1.0, 1.0 - biofeedbackData.voiceStress));
      
      // Adapt environmental stimuli based on heart rate
      const hrFactor = (biofeedbackData.heartRate - 60) / 40; // Normalize to 0-1
      newParams.environmentalStimuli.lighting.intensity = Math.max(0.3, Math.min(2.0, 1.0 + hrFactor * 0.5));
      
      // Adapt audio based on attention level
      newParams.environmentalStimuli.audio.volume = Math.max(0.1, Math.min(1.0, cognitiveState.focusLevel || 0.7));
      
      setProceduralParams(newParams);
    }
  }, [biofeedbackData, cognitiveState, adaptationEnabled]);

  const handleEnvironmentSwitch = (environmentId: string) => {
    setCurrentEnvironment(environmentId);
    onEnvironmentChange(environmentId);
    
    // Adapt procedural parameters based on environment
    const environment = vrEnvironments.find(env => env.id === environmentId);
    if (environment) {
      setProceduralParams(prev => ({
        ...prev,
        complexity: environment.proceduralComplexity,
        emotionalValence: environment.emotionResponsiveness,
        adaptationRate: environment.biofeedbackIntegration ? 1.0 : 0.3
      }));
    }
  };

  const handleSensorCalibration = async (sensorType: string) => {
    setIsCalibrating(true);
    
    // Simulate calibration process
    setBiofeedbackSensors(prev => 
      prev.map(sensor => 
        sensor.type === sensorType 
          ? { ...sensor, status: 'calibrating' }
          : sensor
      )
    );

    // Simulate calibration delay
    setTimeout(() => {
      setBiofeedbackSensors(prev => 
        prev.map(sensor => 
          sensor.type === sensorType 
            ? { ...sensor, status: 'connected', quality: Math.random() * 0.3 + 0.7 }
            : sensor
        )
      );
      setIsCalibrating(false);
      onBiofeedbackCalibration(sensorType);
    }, 3000);
  };

  const getSensorStatusColor = (status: string) => {
    const colors = {
      connected: 'bg-green-100 text-green-800 border-green-200',
      disconnected: 'bg-red-100 text-red-800 border-red-200',
      calibrating: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      error: 'bg-red-100 text-red-800 border-red-200'
    };
    return colors[status as keyof typeof colors] || colors.disconnected;
  };

  const getEnvironmentIcon = (type: string) => {
    const icons = {
      neural_garden: Brain,
      memory_palace: Target,
      cognitive_maze: Crosshair,
      meditation_space: Heart,
      training_arena: Gamepad2,
      collaborative_world: Globe
    };
    return icons[type as keyof typeof icons] || Brain;
  };

  return (
    <div className="space-y-6">
      {/* VR System Overview */}
      <Card className="bg-gradient-to-br from-purple-50/80 to-pink-50/80 backdrop-blur-sm border-purple-200/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-purple-900">
              <Eye className="w-5 h-5" />
              Enhanced VR/AR Cognitive System
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge className="bg-green-100 text-green-800 border-green-200">
                {vrMode.toUpperCase()} Mode
              </Badge>
              <Button
                onClick={() => setAdaptationEnabled(!adaptationEnabled)}
                variant={adaptationEnabled ? 'default' : 'outline'}
                size="sm"
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                <Waves className="w-4 h-4 mr-1" />
                Adaptation: {adaptationEnabled ? 'ON' : 'OFF'}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Current Environment */}
            <div className="bg-white/60 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Globe className="w-4 h-4 text-purple-500" />
                <span className="font-medium text-gray-900">Active Environment</span>
              </div>
              <div className="text-lg font-bold text-gray-900 capitalize">
                {currentEnvironment.replace('_', ' ')}
              </div>
              <div className="text-sm text-purple-600">Real-time adaptation</div>
            </div>

            {/* Emotion Responsiveness */}
            <div className="bg-white/60 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Heart className="w-4 h-4 text-pink-500" />
                <span className="font-medium text-gray-900">Emotion Response</span>
              </div>
              <div className="text-lg font-bold text-gray-900">
                {(proceduralParams.emotionalValence * 100).toFixed(0)}%
              </div>
              <Progress value={proceduralParams.emotionalValence * 100} className="h-2 mt-2" />
            </div>

            {/* Procedural Complexity */}
            <div className="bg-white/60 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Layers3 className="w-4 h-4 text-blue-500" />
                <span className="font-medium text-gray-900">Complexity</span>
              </div>
              <div className="text-lg font-bold text-gray-900">
                {(proceduralParams.complexity * 100).toFixed(0)}%
              </div>
              <Progress value={proceduralParams.complexity * 100} className="h-2 mt-2" />
            </div>

            {/* Adaptation Rate */}
            <div className="bg-white/60 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Activity className="w-4 h-4 text-green-500" />
                <span className="font-medium text-gray-900">Adaptation Rate</span>
              </div>
              <div className="text-lg font-bold text-gray-900">
                {(proceduralParams.adaptationRate * 100).toFixed(0)}%
              </div>
              <Progress value={proceduralParams.adaptationRate * 100} className="h-2 mt-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="environments" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 bg-white/60 backdrop-blur-sm">
          <TabsTrigger value="environments">VR Environments</TabsTrigger>
          <TabsTrigger value="vr-scene">Live VR Scene</TabsTrigger>
          <TabsTrigger value="biofeedback">Biofeedback Sensors</TabsTrigger>
          <TabsTrigger value="procedural">Procedural Controls</TabsTrigger>
        </TabsList>

        {/* VR Environments */}
        <TabsContent value="environments" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {vrEnvironments.map((environment) => {
              const EnvironmentIcon = getEnvironmentIcon(environment.type);
              return (
                <motion.div
                  key={environment.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="group"
                >
                  <Card className={`bg-gradient-to-br from-white/80 to-gray-50/80 backdrop-blur-sm border-gray-200/30 hover:shadow-lg transition-all duration-300 ${
                    currentEnvironment === environment.id ? 'ring-2 ring-purple-400' : ''
                  }`}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <EnvironmentIcon className="w-5 h-5 text-purple-600" />
                          <Badge 
                            variant={currentEnvironment === environment.id ? 'default' : 'outline'}
                            className={currentEnvironment === environment.id ? 'bg-purple-600 text-white' : ''}
                          >
                            {currentEnvironment === environment.id ? 'Active' : 'Available'}
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-600">
                          {(environment.emotionResponsiveness * 100).toFixed(0)}% Responsive
                        </div>
                      </div>
                      <CardTitle className="text-lg">{environment.name}</CardTitle>
                      <p className="text-sm text-gray-600 capitalize">
                        {environment.type.replace('_', ' ')} environment
                      </p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Cognitive Targets */}
                      <div className="space-y-2">
                        <div className="text-sm font-medium text-gray-700">Cognitive Targets</div>
                        <div className="flex flex-wrap gap-1">
                          {environment.cognitiveTargets.map((target, index) => (
                            <Badge key={index} variant="outline" className="text-xs capitalize">
                              {target}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {/* Adaptive Features */}
                      <div className="space-y-2">
                        <div className="text-sm font-medium text-gray-700">Adaptive Features</div>
                        <div className="space-y-1">
                          {environment.adaptiveFeatures.map((feature, index) => (
                            <div key={index} className="text-xs text-gray-600 flex items-center gap-1">
                              <Sparkles className="w-3 h-3 text-purple-500" />
                              {feature}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Environment Stats */}
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-purple-50/60 p-3 rounded-lg">
                          <div className="text-xs text-purple-600 font-medium">Complexity</div>
                          <div className="text-lg font-bold text-purple-900">
                            {(environment.proceduralComplexity * 100).toFixed(0)}%
                          </div>
                        </div>
                        <div className="bg-pink-50/60 p-3 rounded-lg">
                          <div className="text-xs text-pink-600 font-medium">Biofeedback</div>
                          <div className="text-sm font-bold text-pink-900">
                            {environment.biofeedbackIntegration ? 'Enabled' : 'Disabled'}
                          </div>
                        </div>
                      </div>

                      <Button
                        onClick={() => handleEnvironmentSwitch(environment.id)}
                        variant={currentEnvironment === environment.id ? 'default' : 'outline'}
                        className="w-full"
                        disabled={currentEnvironment === environment.id}
                      >
                        {currentEnvironment === environment.id ? 'Currently Active' : 'Enter Environment'}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </TabsContent>

        {/* Live VR Scene */}
        <TabsContent value="vr-scene" className="space-y-4">
          <Card className="bg-gradient-to-br from-blue-50/80 to-indigo-50/80 backdrop-blur-sm border-blue-200/30">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-blue-900">
                  <Monitor className="w-5 h-5" />
                  Real-time VR Environment
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm">
                    <Camera className="w-4 h-4 mr-1" />
                    Screenshot
                  </Button>
                  <Button variant="outline" size="sm">
                    <Maximize className="w-4 h-4 mr-1" />
                    Fullscreen
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="aspect-video bg-black rounded-lg overflow-hidden">
                <Canvas camera={{ position: [0, 5, 10], fov: 75 }}>
                  <VRScene
                    emotion={currentEmotion.dominant}
                    biofeedback={biofeedbackData}
                    cognitiveState={cognitiveState}
                    proceduralParams={proceduralParams}
                  />
                </Canvas>
              </div>
              
              {/* Scene Controls */}
              <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Lighting Intensity</label>
                  <input
                    type="range"
                    min="0.1"
                    max="2.0"
                    step="0.1"
                    value={proceduralParams.environmentalStimuli.lighting.intensity}
                    onChange={(e) => setProceduralParams(prev => ({
                      ...prev,
                      environmentalStimuli: {
                        ...prev.environmentalStimuli,
                        lighting: {
                          ...prev.environmentalStimuli.lighting,
                          intensity: parseFloat(e.target.value)
                        }
                      }
                    }))}
                    className="w-full h-2 bg-blue-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <span className="text-xs text-blue-600">
                    {proceduralParams.environmentalStimuli.lighting.intensity.toFixed(1)}
                  </span>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Particle Density</label>
                  <input
                    type="range"
                    min="0.1"
                    max="1.0"
                    step="0.1"
                    value={proceduralParams.environmentalStimuli.visuals.density}
                    onChange={(e) => setProceduralParams(prev => ({
                      ...prev,
                      environmentalStimuli: {
                        ...prev.environmentalStimuli,
                        visuals: {
                          ...prev.environmentalStimuli.visuals,
                          density: parseFloat(e.target.value)
                        }
                      }
                    }))}
                    className="w-full h-2 bg-blue-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <span className="text-xs text-blue-600">
                    {(proceduralParams.environmentalStimuli.visuals.density * 100).toFixed(0)}%
                  </span>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Audio Volume</label>
                  <input
                    type="range"
                    min="0.0"
                    max="1.0"
                    step="0.1"
                    value={proceduralParams.environmentalStimuli.audio.volume}
                    onChange={(e) => setProceduralParams(prev => ({
                      ...prev,
                      environmentalStimuli: {
                        ...prev.environmentalStimuli,
                        audio: {
                          ...prev.environmentalStimuli.audio,
                          volume: parseFloat(e.target.value)
                        }
                      }
                    }))}
                    className="w-full h-2 bg-blue-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <span className="text-xs text-blue-600">
                    {(proceduralParams.environmentalStimuli.audio.volume * 100).toFixed(0)}%
                  </span>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Interactivity</label>
                  <input
                    type="range"
                    min="0.0"
                    max="1.0"
                    step="0.1"
                    value={proceduralParams.environmentalStimuli.visuals.interactivity}
                    onChange={(e) => setProceduralParams(prev => ({
                      ...prev,
                      environmentalStimuli: {
                        ...prev.environmentalStimuli,
                        visuals: {
                          ...prev.environmentalStimuli.visuals,
                          interactivity: parseFloat(e.target.value)
                        }
                      }
                    }))}
                    className="w-full h-2 bg-blue-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <span className="text-xs text-blue-600">
                    {(proceduralParams.environmentalStimuli.visuals.interactivity * 100).toFixed(0)}%
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Biofeedback Sensors */}
        <TabsContent value="biofeedback" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {biofeedbackSensors.map((sensor) => (
              <motion.div
                key={sensor.type}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-gradient-to-br from-emerald-50/80 to-teal-50/80 backdrop-blur-sm border-emerald-200/30">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Activity className="w-4 h-4 text-emerald-600" />
                        <Badge className={getSensorStatusColor(sensor.status)}>
                          {sensor.status.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600">
                        Quality: {(sensor.quality * 100).toFixed(0)}%
                      </div>
                    </div>
                    <CardTitle className="text-lg capitalize">
                      {sensor.type.replace('_', ' ')} Sensor
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Signal Quality */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-700">Signal Quality</span>
                        <span className="text-gray-600">{(sensor.quality * 100).toFixed(0)}%</span>
                      </div>
                      <Progress value={sensor.quality * 100} className="h-2" />
                    </div>

                    {/* Calibration Data */}
                    {sensor.calibrationData && (
                      <div className="space-y-2">
                        <div className="text-sm font-medium text-gray-700">Calibration Data</div>
                        <div className="bg-white/60 p-3 rounded-lg">
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            {Object.entries(sensor.calibrationData).map(([key, value]) => (
                              <div key={key} className="flex justify-between">
                                <span className="capitalize text-gray-600">{key}:</span>
                                <span className="font-medium">
                                  {typeof value === 'number' ? value.toFixed(2) : String(value)}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Sensor Controls */}
                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleSensorCalibration(sensor.type)}
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        disabled={isCalibrating || sensor.status === 'calibrating'}
                      >
                        {sensor.status === 'calibrating' ? (
                          <RotateCw className="w-4 h-4 mr-1 animate-spin" />
                        ) : (
                          <Target className="w-4 h-4 mr-1" />
                        )}
                        Calibrate
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                      >
                        <Settings className="w-4 h-4 mr-1" />
                        Config
                      </Button>
                    </div>

                    {/* Last Reading */}
                    <div className="text-xs text-gray-500">
                      Last reading: {sensor.lastReading > 0 ? new Date(sensor.lastReading).toLocaleTimeString() : 'Never'}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {/* Procedural Controls */}
        <TabsContent value="procedural" className="space-y-4">
          <Card className="bg-gradient-to-br from-orange-50/80 to-yellow-50/80 backdrop-blur-sm border-orange-200/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-900">
                <Sliders className="w-5 h-5" />
                Procedural Generation Controls
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Core Parameters */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-medium text-gray-900">Core Parameters</h4>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">Complexity Level</label>
                      <input
                        type="range"
                        min="0.1"
                        max="1.0"
                        step="0.1"
                        value={proceduralParams.complexity}
                        onChange={(e) => setProceduralParams(prev => ({
                          ...prev,
                          complexity: parseFloat(e.target.value)
                        }))}
                        className="w-full h-2 bg-orange-200 rounded-lg appearance-none cursor-pointer"
                      />
                      <span className="text-xs text-orange-600">
                        {(proceduralParams.complexity * 100).toFixed(0)}%
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">Emotional Valence</label>
                      <input
                        type="range"
                        min="0.0"
                        max="1.0"
                        step="0.1"
                        value={proceduralParams.emotionalValence}
                        onChange={(e) => setProceduralParams(prev => ({
                          ...prev,
                          emotionalValence: parseFloat(e.target.value)
                        }))}
                        className="w-full h-2 bg-orange-200 rounded-lg appearance-none cursor-pointer"
                      />
                      <span className="text-xs text-orange-600">
                        {(proceduralParams.emotionalValence * 100).toFixed(0)}%
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">Cognitive Load</label>
                      <input
                        type="range"
                        min="0.0"
                        max="1.0"
                        step="0.1"
                        value={proceduralParams.cognitiveLoad}
                        onChange={(e) => setProceduralParams(prev => ({
                          ...prev,
                          cognitiveLoad: parseFloat(e.target.value)
                        }))}
                        className="w-full h-2 bg-orange-200 rounded-lg appearance-none cursor-pointer"
                      />
                      <span className="text-xs text-orange-600">
                        {(proceduralParams.cognitiveLoad * 100).toFixed(0)}%
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">Adaptation Rate</label>
                      <input
                        type="range"
                        min="0.1"
                        max="1.0"
                        step="0.1"
                        value={proceduralParams.adaptationRate}
                        onChange={(e) => setProceduralParams(prev => ({
                          ...prev,
                          adaptationRate: parseFloat(e.target.value)
                        }))}
                        className="w-full h-2 bg-orange-200 rounded-lg appearance-none cursor-pointer"
                      />
                      <span className="text-xs text-orange-600">
                        {(proceduralParams.adaptationRate * 100).toFixed(0)}%
                      </span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-medium text-gray-900">Personalized Factors</h4>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">Attention Factor</label>
                      <input
                        type="range"
                        min="0.0"
                        max="1.0"
                        step="0.1"
                        value={proceduralParams.personalizedFactors.attention}
                        onChange={(e) => setProceduralParams(prev => ({
                          ...prev,
                          personalizedFactors: {
                            ...prev.personalizedFactors,
                            attention: parseFloat(e.target.value)
                          }
                        }))}
                        className="w-full h-2 bg-orange-200 rounded-lg appearance-none cursor-pointer"
                      />
                      <span className="text-xs text-orange-600">
                        {(proceduralParams.personalizedFactors.attention * 100).toFixed(0)}%
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">Memory Factor</label>
                      <input
                        type="range"
                        min="0.0"
                        max="1.0"
                        step="0.1"
                        value={proceduralParams.personalizedFactors.memory}
                        onChange={(e) => setProceduralParams(prev => ({
                          ...prev,
                          personalizedFactors: {
                            ...prev.personalizedFactors,
                            memory: parseFloat(e.target.value)
                          }
                        }))}
                        className="w-full h-2 bg-orange-200 rounded-lg appearance-none cursor-pointer"
                      />
                      <span className="text-xs text-orange-600">
                        {(proceduralParams.personalizedFactors.memory * 100).toFixed(0)}%
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">Processing Factor</label>
                      <input
                        type="range"
                        min="0.0"
                        max="1.0"
                        step="0.1"
                        value={proceduralParams.personalizedFactors.processing}
                        onChange={(e) => setProceduralParams(prev => ({
                          ...prev,
                          personalizedFactors: {
                            ...prev.personalizedFactors,
                            processing: parseFloat(e.target.value)
                          }
                        }))}
                        className="w-full h-2 bg-orange-200 rounded-lg appearance-none cursor-pointer"
                      />
                      <span className="text-xs text-orange-600">
                        {(proceduralParams.personalizedFactors.processing * 100).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                </div>

                {/* Environmental Stimuli */}
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">Environmental Stimuli</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* Lighting Controls */}
                    <div className="bg-white/60 p-4 rounded-lg">
                      <div className="text-sm font-medium text-gray-700 mb-3">Lighting</div>
                      <div className="space-y-3">
                        <div>
                          <label className="text-xs text-gray-600">Intensity</label>
                          <input
                            type="range"
                            min="0.1"
                            max="2.0"
                            step="0.1"
                            value={proceduralParams.environmentalStimuli.lighting.intensity}
                            onChange={(e) => setProceduralParams(prev => ({
                              ...prev,
                              environmentalStimuli: {
                                ...prev.environmentalStimuli,
                                lighting: {
                                  ...prev.environmentalStimuli.lighting,
                                  intensity: parseFloat(e.target.value)
                                }
                              }
                            }))}
                            className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                          />
                          <span className="text-xs text-gray-500">
                            {proceduralParams.environmentalStimuli.lighting.intensity.toFixed(1)}
                          </span>
                        </div>
                        
                        <div>
                          <label className="text-xs text-gray-600">Color</label>
                          <input
                            type="color"
                            value={proceduralParams.environmentalStimuli.lighting.color}
                            onChange={(e) => setProceduralParams(prev => ({
                              ...prev,
                              environmentalStimuli: {
                                ...prev.environmentalStimuli,
                                lighting: {
                                  ...prev.environmentalStimuli.lighting,
                                  color: e.target.value
                                }
                              }
                            }))}
                            className="w-full h-6 rounded border border-gray-200"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Audio Controls */}
                    <div className="bg-white/60 p-4 rounded-lg">
                      <div className="text-sm font-medium text-gray-700 mb-3">Audio</div>
                      <div className="space-y-3">
                        <div>
                          <label className="text-xs text-gray-600">Volume</label>
                          <input
                            type="range"
                            min="0.0"
                            max="1.0"
                            step="0.1"
                            value={proceduralParams.environmentalStimuli.audio.volume}
                            onChange={(e) => setProceduralParams(prev => ({
                              ...prev,
                              environmentalStimuli: {
                                ...prev.environmentalStimuli,
                                audio: {
                                  ...prev.environmentalStimuli.audio,
                                  volume: parseFloat(e.target.value)
                                }
                              }
                            }))}
                            className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                          />
                          <span className="text-xs text-gray-500">
                            {(proceduralParams.environmentalStimuli.audio.volume * 100).toFixed(0)}%
                          </span>
                        </div>
                        
                        <div>
                          <label className="text-xs text-gray-600">Frequency</label>
                          <select
                            value={proceduralParams.environmentalStimuli.audio.frequency}
                            onChange={(e) => setProceduralParams(prev => ({
                              ...prev,
                              environmentalStimuli: {
                                ...prev.environmentalStimuli,
                                audio: {
                                  ...prev.environmentalStimuli.audio,
                                  frequency: e.target.value
                                }
                              }
                            }))}
                            className="w-full text-xs p-1 border border-gray-200 rounded"
                          >
                            <option value="gamma">Gamma (40Hz)</option>
                            <option value="beta">Beta (20Hz)</option>
                            <option value="alpha">Alpha (10Hz)</option>
                            <option value="theta">Theta (6Hz)</option>
                            <option value="delta">Delta (2Hz)</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Haptics Controls */}
                    <div className="bg-white/60 p-4 rounded-lg">
                      <div className="text-sm font-medium text-gray-700 mb-3">Haptics</div>
                      <div className="space-y-3">
                        <div>
                          <label className="text-xs text-gray-600">Intensity</label>
                          <input
                            type="range"
                            min="0.0"
                            max="1.0"
                            step="0.1"
                            value={proceduralParams.environmentalStimuli.haptics.intensity}
                            onChange={(e) => setProceduralParams(prev => ({
                              ...prev,
                              environmentalStimuli: {
                                ...prev.environmentalStimuli,
                                haptics: {
                                  ...prev.environmentalStimuli.haptics,
                                  intensity: parseFloat(e.target.value)
                                }
                              }
                            }))}
                            className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                          />
                          <span className="text-xs text-gray-500">
                            {(proceduralParams.environmentalStimuli.haptics.intensity * 100).toFixed(0)}%
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-1">
                          <input
                            type="checkbox"
                            checked={proceduralParams.environmentalStimuli.haptics.adaptive}
                            onChange={(e) => setProceduralParams(prev => ({
                              ...prev,
                              environmentalStimuli: {
                                ...prev.environmentalStimuli,
                                haptics: {
                                  ...prev.environmentalStimuli.haptics,
                                  adaptive: e.target.checked
                                }
                              }
                            }))}
                            className="w-3 h-3"
                          />
                          <label className="text-xs text-gray-600">Adaptive</label>
                        </div>
                      </div>
                    </div>

                    {/* Visual Controls */}
                    <div className="bg-white/60 p-4 rounded-lg">
                      <div className="text-sm font-medium text-gray-700 mb-3">Visuals</div>
                      <div className="space-y-3">
                        <div>
                          <label className="text-xs text-gray-600">Density</label>
                          <input
                            type="range"
                            min="0.1"
                            max="1.0"
                            step="0.1"
                            value={proceduralParams.environmentalStimuli.visuals.density}
                            onChange={(e) => setProceduralParams(prev => ({
                              ...prev,
                              environmentalStimuli: {
                                ...prev.environmentalStimuli,
                                visuals: {
                                  ...prev.environmentalStimuli.visuals,
                                  density: parseFloat(e.target.value)
                                }
                              }
                            }))}
                            className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                          />
                          <span className="text-xs text-gray-500">
                            {(proceduralParams.environmentalStimuli.visuals.density * 100).toFixed(0)}%
                          </span>
                        </div>
                        
                        <div>
                          <label className="text-xs text-gray-600">Interactivity</label>
                          <input
                            type="range"
                            min="0.0"
                            max="1.0"
                            step="0.1"
                            value={proceduralParams.environmentalStimuli.visuals.interactivity}
                            onChange={(e) => setProceduralParams(prev => ({
                              ...prev,
                              environmentalStimuli: {
                                ...prev.environmentalStimuli,
                                visuals: {
                                  ...prev.environmentalStimuli.visuals,
                                  interactivity: parseFloat(e.target.value)
                                }
                              }
                            }))}
                            className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                          />
                          <span className="text-xs text-gray-500">
                            {(proceduralParams.environmentalStimuli.visuals.interactivity * 100).toFixed(0)}%
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
